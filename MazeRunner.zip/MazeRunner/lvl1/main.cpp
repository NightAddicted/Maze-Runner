#include <windows.h>

#include <cstdio>

#include <GL/gl.h>

#include <GL/glut.h>

#include <math.h>

#define PI 3.14159265358979323846

GLfloat position5 = 0.0f;
GLfloat speed5 = 0.03f;
GLfloat position4 = 0.0f;
GLfloat speed4 = 0.03f;
GLfloat position3 = 0.0f;
GLfloat speed3 = 0.03f;
GLfloat position2 = 0.0f;
GLfloat speed2 = 0.03f;
GLfloat position1 = 0.0f;
GLfloat speed1 = 0.03f;
GLfloat charX = -0.88f;  // Starting position
GLfloat charY = 0.65f;
GLfloat jumpVelocity = 0.00f;
GLfloat gravity = -0.006f;
bool isJumping = false;
// New movement and character parameters
const float CHAR_WIDTH = 0.05f;
const float CHAR_HEIGHT = 0.12f;
const float BUFFER = 0.03f;
bool isNextLevelLaunched = false;
// Initial position of the invisible quad
float characterX = -0.88;
float characterY = 0.65;
const float moveStep = 0.02f;

void playSound(const char* filename) {
    PlaySound(TEXT(filename), NULL, SND_ASYNC | SND_FILENAME);
}

void nextlevel() {
    if (isNextLevelLaunched) {
        return;
    }

    float spikes[1][4] = {
        {0.53f, 0.63f, 0.50f , 0.70f},
    };

    float charLeft = charX - (CHAR_WIDTH / 2) - BUFFER;
    float charRight = charX + (CHAR_WIDTH / 2) + BUFFER;
    float charTop = charY + (CHAR_HEIGHT / 0.5) + BUFFER;
    float charBottom = charY - (CHAR_HEIGHT / 1.2) - BUFFER;

    for (int i = 0; i < 1; i++) {
        float spikeLeft = spikes[i][0];
        float spikeRight = spikes[i][1];
        float spikeTop = spikes[i][2];
        float spikeBottom = spikes[i][3];

        if (!(charRight < spikeLeft || charLeft > spikeRight || charTop < spikeBottom || charBottom > spikeTop)) {
            isNextLevelLaunched = true;
            system("start D:\\Desktop\\MazeRunner\\level2\\bin\\Debug\\level2.exe");
            exit(0);
        }
    }
}


void updateCharacterPosition(int value) {
    if (isJumping) {
        // Update jumping
        characterY += jumpVelocity;
        jumpVelocity += gravity;

        // Check if the character has hit the ground
        if (characterY <= 0.65f) { // Adjust to ground level
            characterY = 0.65f;
            isJumping = false;
            jumpVelocity = 0.0f;
        }
    }

    glutPostRedisplay(); // Request redisplay to update the screen
    glutTimerFunc(16, updateCharacterPosition, 0); // 60 FPS update
}



//


void updateb5(int value5) {
    position5 -= speed5;
    if (position5 < -0.50f) {
        position5 = 0.10;
    }
    glutPostRedisplay();
    glutTimerFunc(100, updateb5, 0);
}

void updateb4(int value4) {
    position4 -= speed4;
    if (position4  <-0.50f) {
        position4 = 0.10;
    }
    glutPostRedisplay();
    glutTimerFunc(100, updateb4, 0);
}

void updateb3(int value3) {
    position3 -= speed3;
    if (position3  <-0.50f) {
        position3 = 0.10;
    }
    glutPostRedisplay();
    glutTimerFunc(100, updateb3, 0);
}


void updateb2(int value2) {
    position2 -= speed2;
    if (position2  <-0.50f) {
        position2 = 0.10;
    }
    glutPostRedisplay();
    glutTimerFunc(100, updateb2, 0);
}

void updateb1(int value1) {
    position1 -= speed1;
    if (position1  <-0.50f) {
        position1 = 0.10;
    }
    glutPostRedisplay();
    glutTimerFunc(100, updateb1, 0);
}
//
void display()
{

    glClearColor(0.239f, 0.141f, 0.063f, 0.0f);
	glClear(GL_COLOR_BUFFER_BIT);


    //Background
	glBegin(GL_QUADS);
	glColor3ub(101, 67, 33);
	glVertex2f(-1,1);
	glVertex2f(-1,-1);
	glVertex2f(1,-1);
	glVertex2f(1,1);
	glEnd();

	//polu


//LASER BEAM
    glPushMatrix();//5
    glTranslatef(0.0f, position5, 0.0f);
	glPointSize(6.0f);
	glBegin(GL_POINTS);
	glColor3ub(255, 0, 0);
	glVertex2f(0.52,0.16);
	glEnd();
    glPopMatrix();

    glPushMatrix();//4
    glTranslatef(0.0f, position4, 0.0f);
	glPointSize(6.0f);
	glBegin(GL_POINTS);
	glColor3ub(255, 0, 0);
	glVertex2f(0.18,0.80);
	glEnd();
    glPopMatrix();

    glPushMatrix();//3
    glTranslatef(0.0f, position3, 0.0f);
	glPointSize(6.0f);
	glBegin(GL_POINTS);
	glColor3ub(255, 0, 0);
	glVertex2f(-0.15,0.92);
	glEnd();
    glPopMatrix();

    glPushMatrix();//2
    glTranslatef(0.0f, position2, 0.0f);
	glPointSize(6.0f);
	glBegin(GL_POINTS);
	glColor3ub(255, 0, 0);
	glVertex2f(-0.28,0.10);
	glEnd();
    glPopMatrix();

    glPushMatrix();//1
    glTranslatef(0.0f, position1, 0.0f);
	glPointSize(6.0f);
	glBegin(GL_POINTS);
	glColor3ub(255, 0, 0);
	glVertex2f(-0.68,0.10);
	glEnd();
    glPopMatrix();

    //backgrouncolor


    //maze

	glBegin(GL_QUADS);
    glColor3ub(0, 0, 0);
    glVertex2f(-1.0f, 1.0f);
	glVertex2f(-1.0f,  0.82f);
	glVertex2f(1.0f, 0.82f);
	glVertex2f(1.0f,  1.0f);
	glEnd();

	glBegin(GL_QUADS);
    glColor3ub(0, 0, 0);
    glVertex2f(-1.0f,1.0f);
	glVertex2f(-0.93f,  1.f);
	glVertex2f(-0.93f, -1.0f);
	glVertex2f(-1.0f,  -1.0f);
	glEnd();

	glBegin(GL_QUADS);
    glColor3ub(0, 0, 0);
    glVertex2f(1.0f,1.0f);
	glVertex2f(0.93f,  1.f);
	glVertex2f(0.93f, -1.0f);
	glVertex2f(1.0f,  -1.0f);
	glEnd();

	glBegin(GL_QUADS);
    glColor3ub(0, 0, 0);
    glVertex2f(-1.0f,- 1.0f);
	glVertex2f(-1.0f, - 0.88f);
	glVertex2f(1.0f, -0.88f);
	glVertex2f(1.0f, - 1.0f);
	glEnd();

	glBegin(GL_QUADS);
    glColor3ub(0, 0, 0);
    glVertex2f(-1.0f, 0.59f);
	glVertex2f(-1.0f,  0.47f);
	glVertex2f(-0.73f, 0.47f);
	glVertex2f(-0.73f,  0.59f);
	glEnd();

	glBegin(GL_QUADS);
    glColor3ub(0, 0, 0);
    glVertex2f(-0.83f, 0.24f);
	glVertex2f(-0.83f,  0.12f);
	glVertex2f(-0.10f, 0.12f);
	glVertex2f(-0.10f,  0.24f);
	glEnd();

	glBegin(GL_QUADS);
    glColor3ub(0, 0, 0);
    glVertex2f(-0.60f, 1.0f);
	glVertex2f(-0.50f,  1.0f);
	glVertex2f(-0.50f, 0.12f);
	glVertex2f(-0.60f,  0.12f);
	glEnd();

	glBegin(GL_QUADS);
    glColor3ub(0, 0, 0);
    glVertex2f(-0.50f, 0.35f);
	glVertex2f(-0.50f,  0.24f);
	glVertex2f(-0.43f, 0.24f);
	glVertex2f(-0.43f,  0.35f);
	glEnd();

	glBegin(GL_QUADS);
    glColor3ub(0, 0, 0);
    glVertex2f(-1.0f, -0.29f);
	glVertex2f(-1.0f,  -1.0f);
	glVertex2f(-0.53f, -1.0f);
	glVertex2f(-0.53f,  -0.29f);
	glEnd();


	glBegin(GL_QUADS);
    glColor3ub(0, 0, 0);
    glVertex2f(-0.33f, 0.53f);
	glVertex2f(-0.33f,  0.41f);
	glVertex2f(0.30f, 0.41f);
	glVertex2f(0.30f,  0.53f);
	glEnd();


    glBegin(GL_QUADS);
    glColor3ub(0, 0, 0);
    glVertex2f(0.07f, 0.53f);
	glVertex2f(0.07f,  -1.0f);
	glVertex2f(0.30f,-1.0f);
	glVertex2f(0.30f,  0.53f);
	glEnd();

	glBegin(GL_QUADS);
    glColor3ub(0, 0, 0);
    glVertex2f(0.0f, 0.06f);
	glVertex2f(0.07f,  0.06f);
	glVertex2f(0.07f,-1.0f);
	glVertex2f(0.0f,  -1.0f);
	glEnd();

	glBegin(GL_QUADS);
    glColor3ub(0, 0, 0);
    glVertex2f(-0.07f, -1.0f);
	glVertex2f(-0.07f,  -0.18f);
	glVertex2f(0.0f,-0.18f);
	glVertex2f(0.0f,  -1.0f);
	glEnd();

	glBegin(GL_QUADS);
    glColor3ub(0, 0, 0);
    glVertex2f(0.43f, 1.0f);
	glVertex2f(0.53f,  1.0f);
	glVertex2f(0.53f,0.18f);
	glVertex2f(0.43f,  0.18f);
	glEnd();

	glBegin(GL_QUADS);
    glColor3ub(0, 0, 0);
    glVertex2f(0.43f, 0.47f);
	glVertex2f(0.43f,  0.18f);
	glVertex2f(0.77f,0.18f);
	glVertex2f(0.77f,  0.47f);
	glEnd();

	glBegin(GL_QUADS);
    glColor3ub(0, 0, 0);
    glVertex2f(0.43f, 0.38f);
	glVertex2f(0.43f,  0.29f);
	glVertex2f(0.87f,0.29f);
	glVertex2f(0.87f,  0.38f);
	glEnd();



	//TRAp
	glBegin(GL_QUADS);
    glColor3ub(0, 0, 0);
    glVertex2f(-0.43f, -0.35f);
	glVertex2f(-0.43f,  -0.41f);
	glVertex2f(-0.33f,-0.41f);
	glVertex2f(-0.33f,  -0.35f);

	glVertex2f(-0.23f, -0.35f);
	glVertex2f(-0.23f,  -0.41f);
	glVertex2f(-0.13f,-0.41f);
	glVertex2f(-0.13f,  -0.35f);
//tarp3
	glVertex2f(0.30f, -0.12f);
	glVertex2f(0.30f,  -0.18f);
	glVertex2f(0.40f,-0.18f);
	glVertex2f(0.40f,  -0.12f);
//trap5
	glVertex2f(0.63f, -0.12f);
	glVertex2f(0.63f,  -0.18f);
	glVertex2f(0.73f,-0.18f);
	glVertex2f(0.73f,  -0.12f);
//trap  4
	glVertex2f(0.47f, -0.29f);
	glVertex2f(0.47f,  -0.35f);
	glVertex2f(0.57f,-0.35f);
	glVertex2f(0.57f,  -0.29f);



	glEnd();



//
	glBegin(GL_QUADS);
    glColor3ub(0, 0, 0);
    glVertex2f(0.73f, 0.0f);
	glVertex2f(1.0f,  0.0f);
	glVertex2f(1.0f,-1.0f);
	glVertex2f(0.73f,  -1.0f);
	glEnd();

	glBegin(GL_QUADS);
    glColor3ub(0, 0, 0);
    glVertex2f(0.87f, 0.14f);
	glVertex2f(1.0f,  0.14f);
	glVertex2f(1.0f,-1.0f);
	glVertex2f(0.87f,  -1.0f);
	glEnd();

	glBegin(GL_QUADS);
    glColor3ub(0, 0, 0);
    glVertex2f(-1.0f, -0.06f);
	glVertex2f(-0.87f,  -0.06f);
	glVertex2f(-1.0f,-0.29f);
	glVertex2f(-0.87f,  -0.29f);
	glEnd();


	glBegin(GL_QUADS);
    glColor3ub(0, 0, 0);
    glVertex2f(-1.0f, -0.06f);
	glVertex2f(-0.87f,  -0.06f);
	glVertex2f(-1.0f,-0.29f);
	glVertex2f(-0.87f,  -0.29f);
	glEnd();





//laser5



glBegin(GL_POLYGON);
	glColor3ub(246, 0, 0);
	glVertex2f(0.52,0.18);
	glVertex2f(0.47,0.18);
	glVertex2f(0.49,0.16);
	glVertex2f(0.51,0.16);
	glVertex2f(0.51,0.14);
	glVertex2f(0.53,0.14);
	glVertex2f(0.53,0.16);
	glVertex2f(0.55,0.16);
	glVertex2f(0.57,0.18);
	glEnd();


	//laser4
	glBegin(GL_POLYGON);
	glColor3ub(246, 0, 0);
	glVertex2f(0.18,0.82);
	glVertex2f(0.13,0.82);
	glVertex2f(0.15,0.80);
	glVertex2f(0.17,0.80);
	glVertex2f(0.17,0.78);
	glVertex2f(0.19,0.78);
	glVertex2f(0.19,0.80);
	glVertex2f(0.21,0.80);
	glVertex2f(0.23,0.82);
	glEnd();



	//laser3
	glBegin(GL_POLYGON);
	glColor3ub(246, 0, 0);
	glVertex2f(-0.15,0.82);
	glVertex2f(-0.10,0.82);
	glVertex2f(-0.12,0.80);
	glVertex2f(-0.14,0.80);
	glVertex2f(-0.14,0.78);
	glVertex2f(-0.16,0.78);
	glVertex2f(-0.16,0.80);
	glVertex2f(-0.18,0.80);
	glVertex2f(-0.20,0.82);
	glEnd();

	//laser2
	glBegin(GL_POLYGON);
	glColor3ub(246, 0, 0);
	glVertex2f(-0.28,0.12);
	glVertex2f(-0.33,0.12);
	glVertex2f(-0.31,0.10);
	glVertex2f(-0.29,0.10);
	glVertex2f(-0.29,0.08);
	glVertex2f(-0.27,0.08);
	glVertex2f(-0.27,0.10);
	glVertex2f(-0.25,0.10);
	glVertex2f(-0.23,0.12);
	glEnd();

	glBegin(GL_POLYGON);//1
	glColor3ub(246, 0, 0);
	glVertex2f(-0.68,0.12);
	glVertex2f(-0.73,0.12);
	glVertex2f(-0.71,0.10);
	glVertex2f(-0.69,0.10);
	glVertex2f(-0.69,0.08);
	glVertex2f(-0.67,0.08);
	glVertex2f(-0.67,0.10);
	glVertex2f(-0.65,0.10);
	glVertex2f(-0.63,0.12);
	glEnd();

	glBegin(GL_LINES);
	glColor3ub(255,0,0);
	glVertex2f(0.53f,0.53f);
	glVertex2f(0.63f,0.53f);
	glEnd();


	// Character (just a simple square for now)
    glPushMatrix();
    glTranslatef(characterX, characterY, 0.0f); // Move character to the new position
    glBegin(GL_QUADS);
	glColor3ub(100,100,100);
  glVertex2f(-0.01, 0.0);
  glVertex2f(0.0075, 0.0);
  glVertex2f(0.0075, -0.03);
  glVertex2f(-0.01, -0.03);
  glVertex2f(0.0125, 0.0);
  glVertex2f(0.0125, -0.03);
  glVertex2f(0.02, -0.03);
  glVertex2f(0.02, 0.0);

  // "body"
  glVertex2f(-0.01, 0.0);
  glVertex2f(0.02, 0.0);
  glVertex2f(0.02, 0.03);
  glVertex2f(-0.01, 0.03);

  // "hand"
  glVertex2f(-0.02, 0.0);
  glVertex2f(-0.02, 0.03);
  glVertex2f(-0.013, 0.03);
  glVertex2f(-0.013, 0.0);
  glVertex2f(0.023, 0.0);
  glVertex2f(0.03, 0.0);
  glVertex2f(0.03, 0.03);
  glVertex2f(0.023, 0.03);

  // "head"
  glVertex2f(-0.01, 0.04);
  glVertex2f(0.02, 0.04);
  glVertex2f(0.02, 0.07);
  glVertex2f(-0.01, 0.07);
  glEnd();


	/*glVertex2f(-0.87,0.59);//l
	glVertex2f(-0.87,0.62);
	glVertex2f(-0.861,0.62);
	glVertex2f(-0.861,0.59);
	glVertex2f(-0.85,0.59);
	glVertex2f(-0.85,0.62);
	glVertex2f(-0.859,0.62);
	glVertex2f(-0.859,0.59);

	glVertex2f(-0.87,0.62);//b
	glVertex2f(-0.85,0.62);
	glVertex2f(-0.85,0.65);
	glVertex2f(-0.87,0.65);

	glVertex2f(-0.871,0.62);//h
	glVertex2f(-0.871,0.65);
	glVertex2f(-0.878,0.65);
	glVertex2f(-0.878,0.62);
	glVertex2f(-0.842,0.62);
	glVertex2f(-0.849,0.62);
	glVertex2f(-0.849,0.65);
	glVertex2f(-0.842,0.65);


	glVertex2f(-0.87,0.66);
	glVertex2f(-0.85,0.66);
	glVertex2f(-0.85,0.69);
	glVertex2f(-0.87,0.69);
    glEnd();*/
    glPopMatrix();

    glFlush();
}

bool isWall(float x, float y) {
  unsigned char pixel[3];
  glReadPixels(
    (x + 1.0f) * glutGet(GLUT_WINDOW_WIDTH) / 2,
    (y + 1.0f) * glutGet(GLUT_WINDOW_HEIGHT) / 2,
    1, 1, GL_RGB, GL_UNSIGNED_BYTE, pixel
  );
  return (pixel[0] == 0 && pixel[1] == 0 && pixel[2] == 0);
}

// Improved collision detection
bool canMove(float newX, float newY) {
  // Basic boundary check
  if (newX < -0.95f || newX > 0.95f || newY < -0.92f || newY > 0.86f) {
    return false;
  }

  // Check multiple points around the character for collision
  float checkPoints[][2] = {
    {
      newX - CHAR_WIDTH / 2, newY
    }, // Left
    {
      newX + CHAR_WIDTH / 2,
      newY
    }, // Right
    {
      newX,
      newY + CHAR_HEIGHT / 2
    }, // Top
    {
      newX,
      newY - CHAR_HEIGHT / 2
    }, // Bottom
    {
      newX - CHAR_WIDTH / 2,
      newY + CHAR_HEIGHT / 2
    }, // Top-left
    {
      newX + CHAR_WIDTH / 2,
      newY + CHAR_HEIGHT / 2
    }, // Top-right
    {
      newX - CHAR_WIDTH / 2,
      newY - CHAR_HEIGHT / 2
    }, // Bottom-left
    {
      newX + CHAR_WIDTH / 2,
      newY - CHAR_HEIGHT / 2
    } // Bottom-right
  };

  // Check if any of these points would hit a wall
  for (int i = 0; i < 8; i++) {
    if (isWall(checkPoints[i][0], checkPoints[i][1])) {
      return false;
    }
  }

  return true;
}
//collision
// Function to check laser collision with improved detection
bool isCollisionWithLaser(float x, float y) {
    // Define collision boundaries for character
    float charLeft = x - CHAR_WIDTH/2;
    float charRight = x + CHAR_WIDTH/2;
    float charTop = y + CHAR_HEIGHT/2;
    float charBottom = y - CHAR_HEIGHT/2;

    // Helper function to check overlap between rectangles
    auto checkOverlap = [](float r1Left, float r1Top, float r1Right, float r1Bottom,
                          float r2Left, float r2Top, float r2Right, float r2Bottom) {
        return !(r1Right < r2Left ||
                r1Left > r2Right ||
                r1Bottom > r2Top ||
                r1Top < r2Bottom);
    };

    // Check collision with each laser beam
    // Laser 5
    if (checkOverlap(charLeft, charTop, charRight, charBottom,
                     0.47f, 0.18f + position5, 0.57f, 0.14f + position5)) {
                         isNextLevelLaunched = true; // Set the flag
            system("start D:\\Desktop\\MazeRunner\\gameover\\bin\\Debug\\gameover.exe");
            exit(0);
        return true;
    }

    // Laser 4
    if (checkOverlap(charLeft, charTop, charRight, charBottom,
                     0.13f, 0.82f + position4, 0.23f, 0.78f + position4)) {
                         isNextLevelLaunched = true; // Set the flag
            system("start D:\\Desktop\\MazeRunner\\gameover\\bin\\Debug\\gameover.exe");
            exit(0);
        return true;
    }

    // Laser 3
    if (checkOverlap(charLeft, charTop, charRight, charBottom,
                     -0.20f, 0.82f + position3, -0.10f, 0.78f + position3)) {
                         isNextLevelLaunched = true; // Set the flag
            system("start D:\\Desktop\\MazeRunner\\gameover\\bin\\Debug\\gameover.exe");
            exit(0);
        return true;
    }

    // Laser 2
    if (checkOverlap(charLeft, charTop, charRight, charBottom,
                     -0.33f, 0.12f + position2, -0.23f, 0.08f + position2)) {
                         isNextLevelLaunched = true; // Set the flag
            system("start D:\\Desktop\\MazeRunner\\gameover\\bin\\Debug\\gameover.exe");
            exit(0);
        return true;
    }

    // Laser 1
    if (checkOverlap(charLeft, charTop, charRight, charBottom,
                     -0.73f, 0.12f + position1, -0.63f, 0.08f + position1)) {
                         isNextLevelLaunched = true; // Set the flag
            system("start D:\\Desktop\\MazeRunner\\gameover\\bin\\Debug\\gameover.exe");
            exit(0);
        return true;
    }

    return false;
}

// Function to reset character to initial position
void resetCharacter() {
    // Initial position coordinates
    const float INITIAL_X = -0.88f;
    const float INITIAL_Y = 0.65f;

    // Reset position
    characterX = INITIAL_X;
    characterY = INITIAL_Y;

    // Reset movement states
    isJumping = false;
    jumpVelocity = 0.0f;

    // Play death sound (optional)
    playSound("death.wav");

    // Force redisplay
    glutPostRedisplay();
}

// Modified handleKeypress function to include collision check
void handleKeypress(unsigned char key, int x, int y) {
    float newX = characterX;
    float newY = characterY;

    switch (key) {
        case 'w':
            newY += moveStep;
            break;
            case 'e':
            isNextLevelLaunched = true;
            system("start D:\\Desktop\\MazeRunner\\level2\\bin\\Debug\\level2.exe");
            exit(0);
            break;
        case 's':
            newY -= moveStep;
            break;
        case 'a':
            newX -= moveStep;
            break;
        case 'd':
            newX += moveStep;
            break;
        case ' ': // Space bar for jump
            if (!isJumping) {
                isJumping = true;
                jumpVelocity = 0.1f; // Initial jump velocity
                playSound("jump.wav");
            }
            break;
            nextlevel();
        default:
            return;
    }

    // Check if new position is valid and check for laser collision
    if (!isJumping && canMove(newX, newY)) {
        characterX = newX;
        characterY = newY;

        // Check for laser collision after movement
        if (isCollisionWithLaser(characterX, characterY)) {
            resetCharacter();
        } else {
            playSound("move.wav");
        }
    }

    nextlevel();
    glutPostRedisplay();
}

int main(int argc, char** argv) {
    glutInit( & argc, argv);
  glutInitWindowSize(1000, 750);
  glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
  glutCreateWindow("LVL 1 Trans");
  glutDisplayFunc(display);
  glutTimerFunc(100, updateb5, 0);
  glutTimerFunc(100, updateb4, 0);
  glutTimerFunc(100, updateb3, 0);
  glutTimerFunc(100, updateb2, 0);
  glutTimerFunc(100, updateb1, 0);
//  glutTimerFunc(100, updateJump, 0);
  //glutTimerFunc(16, updateCharacterPosition, 0); // 60 FPS timer for character position updates

  glutKeyboardFunc(handleKeypress);
  glutMainLoop();
  return 0;
}
