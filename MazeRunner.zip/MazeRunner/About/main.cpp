#include <windows.h>
#include<cstdio>
#include<GL/gl.h>
#include <GL/glut.h>
#include<math.h>>
# define PI           3.14159265358979323846
bool crossClicked = false;
void renderBitmapString(float x, float y, float z, void *font, char *string)
{
    char *c;
    glRasterPos3f(x, y,z);
    for (c=string; *c != '\0'; c++)
    {
        glutBitmapCharacter(font, *c);
    }
}

void display()
{
	glClearColor(1.0f, 1.0f, 1.0f, 0.0f);
	glClear(GL_COLOR_BUFFER_BIT);

	//BackGround
	glBegin(GL_QUADS);
	glColor3ub(255,255,255);
	glVertex2f(-1,-1);
	glVertex2f(1,-1);
	glVertex2f(1,1);
	glVertex2f(-1,1);
    glEnd();

    //SemiBack
	glBegin(GL_QUADS);
	glColor3ub(217,217,217);
	glVertex2f(-0.80,0.70);
	glVertex2f(-0.80,-0.70);
	glVertex2f(0.80,-0.70);
	glVertex2f(0.80,0.70);

	glEnd();

    //text
    glColor3ub(0,0,0);
    renderBitmapString(-0.70f, 0.47, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "Course: Computer Graphics");

    //text
    glColor3ub(0,0,0);
    renderBitmapString(-0.70f, 0.37, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "Section: E");
    glColor3ub(0,0,0);
    renderBitmapString(-0.70f, 0.27, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "Project Title: Maze Runner");
    glColor3ub(0,0,0);
    renderBitmapString(-0.70f, 0.07, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "Group Members: ");
    glColor3ub(0,0,0);
    renderBitmapString(-0.70f, -0.03, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "1. Robayed Mahmud Rohan ");
    glColor3ub(0,0,0);
    renderBitmapString(-0.70f, -0.13, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "2. Saumik Saha Niloy");
    glColor3ub(0,0,0);
    renderBitmapString(-0.70f, -0.23, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "3. Anik Das");
    glColor3ub(0,0,0);
    renderBitmapString(-0.70f, -0.33, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "4. Md. Emon Hossain");
    glColor3ub(0,0,0);
    renderBitmapString(-0.70f, -0.43, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "5. Afifa Akter Maria");
    glColor3ub(0,0,0);

    //Roll
    renderBitmapString(-0.0f, -0.03, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, ": 22-49475-3 ");
    glColor3ub(0,0,0);
    renderBitmapString(-0.0f, -0.13, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, ": 22-49479-3");
    glColor3ub(0,0,0);
    renderBitmapString(-0.0f, -0.23, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, ": 22-49458-3");
    glColor3ub(0,0,0);
    renderBitmapString(-0.0f, -0.33, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, ": 22-48090-2");
    glColor3ub(0,0,0);
    renderBitmapString(-0.0f, -0.43, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, ": 22-46442-1");

    //text
    glColor3ub(0,0,0);
    renderBitmapString(0.50f, -0.62, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "Continue->");


glFlush();
}
void mouse(int button, int state, int x, int y)
{
    float winSizeX = glutGet(GLUT_WINDOW_WIDTH) / 2.0f;
    float winSizeY = glutGet(GLUT_WINDOW_HEIGHT) / 2.0f;
    float normX = (x - winSizeX) / winSizeX;
    float normY = (winSizeY - y) / winSizeY;

    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
    {
        if (normX >= 0.66 && normX <= 0.74 && normY >= 0.55 && normY <= 0.65)
        {
            crossClicked = true;
        }
    }
}
void idle()
{
    static bool isRunning = false;

    if (isRunning)
        return;

    if (crossClicked)
    {
        isRunning = true;
        crossClicked = false;
        system("D:\\Desktop\\MazeRunner\\Start\\bin\\Debug\\Start.exe");
        isRunning = false;
    }
}
int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitWindowSize(1000, 750);
	glutInitWindowPosition(80, 50);
	glutCreateWindow("CoverPage");
	glutDisplayFunc(display);
	glutMouseFunc(mouse);
    glutIdleFunc(idle);
	glutFullScreen();
	glutMainLoop();
	return 0;
}
