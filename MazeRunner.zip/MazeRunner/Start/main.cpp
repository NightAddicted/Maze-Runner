#include <windows.h>
#include <cstdio>
#include <GL/gl.h>
#include <GL/glut.h>
#include <thread>
#include <math.h>
#define PI 3.14159265358979323846

bool startClicked = false;
bool aboutClicked = false;
bool instructionClicked = false;
bool quitClicked = false;
void playBackgroundMusic() {
    PlaySound(TEXT("Background.wav"), NULL, SND_ASYNC | SND_FILENAME | SND_LOOP);
}

void playSound(const char* filename) {
    PlaySound(TEXT(filename), NULL, SND_ASYNC | SND_FILENAME);
}
void renderBitmapString(float x, float y, float z, void *font, char *string)
{
    char *c;
    glRasterPos3f(x, y, z);
    for (c = string; *c != '\0'; c++)
    {
        glutBitmapCharacter(font, *c);
    }
}

void display()
{
    glClearColor(1.0f, 1.0f, 1.0f, 0.0f);
    glClear(GL_COLOR_BUFFER_BIT);

    // BackGround
    glBegin(GL_QUADS);
    glColor3ub(0, 0, 0);
    glVertex2f(-1, -1);
    glVertex2f(1, -1);
    glVertex2f(1, 1);
    glVertex2f(-1, 1);
    glEnd();

    // Letter M
    glBegin(GL_QUADS);
    glColor3ub(255, 255, 255);
    glVertex2f(-0.47, 0.70);
    glVertex2f(-0.43, 0.70);
    glVertex2f(-0.43, 0.35);
    glVertex2f(-0.47, 0.35);
    glVertex2f(-0.43, 0.65);
    glVertex2f(-0.40, 0.65);
    glVertex2f(-0.40, 0.60);
    glVertex2f(-0.43, 0.60);
    glVertex2f(-0.40, 0.60);
    glVertex2f(-0.37, 0.60);
    glVertex2f(-0.37, 0.55);
    glVertex2f(-0.40, 0.55);
    glVertex2f(-0.37, 0.55);
    glVertex2f(-0.34, 0.55);
    glVertex2f(-0.34, 0.50);
    glVertex2f(-0.37, 0.50);
    glVertex2f(-0.34, 0.55);
    glVertex2f(-0.31, 0.55);
    glVertex2f(-0.31, 0.60);
    glVertex2f(-0.34, 0.60);
    glVertex2f(-0.31, 0.60);
    glVertex2f(-0.28, 0.60);
    glVertex2f(-0.28, 0.65);
    glVertex2f(-0.31, 0.65);
    glVertex2f(-0.28, 0.70);
    glVertex2f(-0.24, 0.70);
    glVertex2f(-0.24, 0.35);
    glVertex2f(-0.28, 0.35);
    glEnd();

    // Letter A
    glBegin(GL_QUADS);
    glColor3ub(255, 255, 255);
    glVertex2f(-0.20, 0.55);
    glVertex2f(0.00, 0.55);
    glVertex2f(0.00, 0.50);
    glVertex2f(-0.20, 0.50);
    glVertex2f(-0.20, 0.35);
    glVertex2f(-0.16, 0.35);
    glVertex2f(-0.16, 0.60);
    glVertex2f(-0.20, 0.60);
    glVertex2f(-0.16, 0.65);
    glVertex2f(-0.12, 0.65);
    glVertex2f(-0.12, 0.60);
    glVertex2f(-0.16, 0.60);
    glVertex2f(-0.08, 0.65);
    glVertex2f(-0.12, 0.65);
    glVertex2f(-0.12, 0.70);
    glVertex2f(-0.08, 0.70);
    glVertex2f(-0.08, 0.65);
    glVertex2f(-0.04, 0.65);
    glVertex2f(-0.04, 0.60);
    glVertex2f(-0.08, 0.60);
    glVertex2f(0.00, 0.60);
    glVertex2f(-0.04, 0.60);
    glVertex2f(-0.04, 0.35);
    glVertex2f(0.00, 0.35);
    glEnd();

    // Letter Z
    glBegin(GL_QUADS);
    glColor3ub(255, 255, 255);
    glVertex2f(0.04, 0.70);
    glVertex2f(0.24, 0.70);
    glVertex2f(0.24, 0.65);
    glVertex2f(0.04, 0.65);
    glVertex2f(0.20, 0.60);
    glVertex2f(0.24, 0.60);
    glVertex2f(0.24, 0.65);
    glVertex2f(0.20, 0.65);
    glVertex2f(0.20, 0.60);
    glVertex2f(0.16, 0.60);
    glVertex2f(0.16, 0.55);
    glVertex2f(0.20, 0.55);
    glVertex2f(0.12, 0.50);
    glVertex2f(0.16, 0.50);
    glVertex2f(0.16, 0.55);
    glVertex2f(0.12, 0.55);
    glVertex2f(0.12, 0.50);
    glVertex2f(0.08, 0.50);
    glVertex2f(0.08, 0.45);
    glVertex2f(0.12, 0.45);
    glVertex2f(0.04, 0.40);
    glVertex2f(0.08, 0.40);
    glVertex2f(0.08, 0.45);
    glVertex2f(0.04, 0.45);
    glVertex2f(0.04, 0.40);
    glVertex2f(0.24, 0.40);
    glVertex2f(0.24, 0.35);
    glVertex2f(0.04, 0.35);
    glEnd();

    // Letter E
    glBegin(GL_QUADS);
    glColor3ub(255, 255, 255);
    glVertex2f(0.28, 0.70);
    glVertex2f(0.48, 0.70);
    glVertex2f(0.48, 0.65);
    glVertex2f(0.28, 0.65);
    glVertex2f(0.28, 0.50);
    glVertex2f(0.48, 0.50);
    glVertex2f(0.48, 0.55);
    glVertex2f(0.28, 0.55);
    glVertex2f(0.28, 0.40);
    glVertex2f(0.48, 0.40);
    glVertex2f(0.48, 0.35);
    glVertex2f(0.28, 0.35);
    glVertex2f(0.28, 0.70);
    glVertex2f(0.32, 0.70);
    glVertex2f(0.32, 0.35);
    glVertex2f(0.28, 0.35);
    glEnd();

    // Line
    glBegin(GL_QUADS);
    glColor3ub(255, 255, 255);
    glVertex2f(-0.53, 0.30);
    glVertex2f(0.53, 0.30);
    glVertex2f(0.53, 0.20);
    glVertex2f(-0.53, 0.20);
    glEnd();

    // LineStart
    glBegin(GL_QUADS);
    glColor3ub(255, 255, 255);
    glVertex2f(-0.23, -0.30);
    glVertex2f(0.23, -0.30);
    glVertex2f(0.23, -0.20);
    glVertex2f(-0.23, -0.20);
    glEnd();

    // text
    glColor3ub(0, 0, 0);
    renderBitmapString(-0.06f, -0.27, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "START");

    // LineAbout
    glBegin(GL_QUADS);
    glColor3ub(255, 255, 255);
    glVertex2f(-0.23, -0.40);
    glVertex2f(0.23, -0.40);
    glVertex2f(0.23, -0.50);
    glVertex2f(-0.23, -0.50);
    glEnd();

    // text
    glColor3ub(0, 0, 0);
    renderBitmapString(-0.16f, -0.47, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "INSTRUCTION");

    // LineQuit
    glBegin(GL_QUADS);
    glColor3ub(255, 255, 255);
    glVertex2f(-0.23, -0.60);
    glVertex2f(0.23, -0.60);
    glVertex2f(0.23, -0.70);
    glVertex2f(-0.23, -0.70);
    glEnd();

    // text
    glColor3ub(0, 0, 0);
    renderBitmapString(-0.08f, -0.67, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "ABOUT");

    glBegin(GL_QUADS);
    glColor3ub(255, 255, 255);
    glVertex2f(-0.23, -0.80);
    glVertex2f(0.23, -0.80);
    glVertex2f(0.23, -0.90);
    glVertex2f(-0.23, -0.90);
    glEnd();

    // text
    glColor3ub(0, 0, 0);
    renderBitmapString(-0.05f, -0.87, 0.0f, GLUT_BITMAP_TIMES_ROMAN_24, "QUIT");
    glFlush();
}

void mouse(int button, int state, int x, int y)
{
    float winSizeX = glutGet(GLUT_WINDOW_WIDTH) / 2.0f;
    float winSizeY = glutGet(GLUT_WINDOW_HEIGHT) / 2.0f;
    float normX = (x - winSizeX) / winSizeX;
    float normY = (winSizeY - y) / winSizeY;

    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
    {
        if (normX >= -0.23 && normX <= 0.23 && normY >= -0.90 && normY <= -0.80)
        {
            quitClicked = true;
        }
        if (normX >= -0.23 && normX <= 0.23 && normY >= -0.70 && normY <= -0.60)
        {
            aboutClicked = true;
        }
        else if (normX >= -0.23 && normX <= 0.23 && normY >= -0.50 && normY <= -0.40) // Fixed condition
        {
            instructionClicked = true;
        }
        else if (normX >= -0.23 && normX <= 0.23 && normY >= -0.30 && normY <= -0.20)
        {
            startClicked = true;
        }
    }
}

void idle()
{
    static bool isRunning = false;

    if (isRunning)
        return;

    if (startClicked)
    {
        isRunning = true;
        startClicked = false;
        system("start D:\\Desktop\\MazeRunner\\lvl1\\bin\\Debug\\lvl1.exe");
        isRunning = false;
    }
    else if (instructionClicked)
    {
        isRunning = true;
        instructionClicked = false;
        system("start D:\\Desktop\\MazeRunner\\Instruction\\bin\\Debug\\Instruction.exe");
        isRunning = false;
    }
    else if (aboutClicked)
    {
        isRunning = true;
        aboutClicked = false;
        system("start D:\\Desktop\\MazeRunner\\About\\bin\\Debug\\About.exe");
        isRunning = false;
    }
    else if (quitClicked)
    {
        quitClicked = false;
        exit(0);
    }
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitWindowSize(1000, 750);
    glutInitWindowPosition(80, 50);
    glutCreateWindow("Start");
    glutDisplayFunc(display);
    glutMouseFunc(mouse);
    glutIdleFunc(idle);
    glutFullScreen();

    playBackgroundMusic();

    glutMainLoop();
    return 0;
}


