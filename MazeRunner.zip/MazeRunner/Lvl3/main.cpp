#include <windows.h>
#include <cstdio>
#include <GL/gl.h>
#include <GL/glut.h>
#include <math.h>
#define PI 3.14159265358979323846
#include <algorithm>
bool isNextLevelLaunched = false;

GLfloat position1 = 0.0f;
GLfloat position2 = 0.0f;
GLfloat position3 = 0.0f;
GLfloat position4 = 0.0f;
GLfloat position5 = 0.0f;
GLfloat position6 = 0.0f;
GLfloat position7 = 0.0f;
GLfloat speed1 = 0.03f;
GLfloat speed5 = 0.03f;

const float INITIAL_X = -0.94f;
const float INITIAL_Y = 0.60f;

const float CHAR_WIDTH = 0.045f;
const float CHAR_HEIGHT = 0.13f;
const float BUFFER = 0.01f;
float jumpStartY = 0.0f;

float characterX = -0.94;
float characterY = 0.60;
const float moveStep = 0.02f;
bool isJumping = false;
float jumpSpeed = 0.04f; // Initial upward speed
//float gravity = 0.001f;  // Gravity to pull the character down
float jumpVelocity = 0.0f; // Current velocity during jump
//const float GRAVITY = 0.001f;       // Downward acceleration
const float FALL_SPEED = 0.01f;  // Controls how fast the character falls

float jumpStartX = 0.0f;  // Store X position where jump started

const float JUMP_INITIAL_VELOCITY = 0.04f;    // Initial upward velocity
const float MAX_JUMP_HEIGHT = 0.5f;           // Maximum jump height
const float GRAVITY = 0.002f;                 // Reduced gravity for smoother fall
const float MIN_JUMP_VELOCITY = -0.015f;      // Terminal velocity when falling
const float GROUND_CHECK_DISTANCE = 0.01f;    // Distance to check for ground

void updateb1(int value1) {
    if (position1 > 0.10f) position1 = -0.10f;
    position1 += speed1;

    glutPostRedisplay();
    glutTimerFunc(300, updateb1, 0);
}

void updateb2(int value) {
    if (position2 > 0.10f) position2 = -0.50f;
    position2 += speed1;

    glutPostRedisplay();
    glutTimerFunc(100, updateb2, 0);
}

void updateb3(int value) {
    if (position3 > 0.50f) position3 = -0.10f;
    position3 += speed1;

    glutPostRedisplay();
    glutTimerFunc(100, updateb3, 0);
}

void updateb4(int value) {
    if (position4 > 0.50f) position4 = -0.10f;
    position4 += speed1;

    glutPostRedisplay();
    glutTimerFunc(100, updateb4, 0);
}

void updateb5(int value) {
    if (position5 <= -0.70f) {
        position5 = 0.0f;
    }
    position5 -= speed5;

    glutPostRedisplay();
    glutTimerFunc(100, updateb5, 0);
}

void updateb6(int value) {
    if (position6 <- 0.50f) position6 = 0.10f;
    position6 -= speed1;

    glutPostRedisplay();
    glutTimerFunc(100, updateb6, 0);
}

void updateb7(int value) {
    if (position7 < -0.70f) {
        position7 = 0.0f;
    }
    position7 -= speed5;

    glutPostRedisplay();
    glutTimerFunc(100, updateb7, 0);
}


// Rotation angle for spinning
float angle = 0.0f;

// Pivot point coordinates
const float pivotX = -0.87f;
const float pivotY = 0.24f;

// Rotation angle for spinning
float angle1 = 0.0f;

// Pivot point coordinates
const float pivotX1 = -0.40f;
const float pivotY1 = 0.53f;

void playSound(const char* filename) {
    PlaySound(TEXT(filename), NULL, SND_ASYNC | SND_FILENAME);
}

void display() {
  glClearColor(1.0f, 1.0f, 1.0f, 0.0f);
  glClear(GL_COLOR_BUFFER_BIT);

  // Background
  glBegin(GL_QUADS);
  glColor3ub(217, 217, 217);
  glVertex2f(-1, -1);
  glVertex2f(1, -1);
  glVertex2f(1, 1);
  glVertex2f(-1, 1);
  glEnd();


  //Combo
    //1
	glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.01,-0.04);
	glVertex2f(0.01,0.04);
	glVertex2f(0.13,0.04);
	glVertex2f(0.13,-0.04);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.14,-0.04);
	glVertex2f(0.14,0.04);
	glVertex2f(0.26,0.04);
	glVertex2f(0.26,-0.04);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.27,-0.04);
	glVertex2f(0.27,0.04);
	glVertex2f(0.40,0.04);
	glVertex2f(0.40,-0.04);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.41,-0.04);
	glVertex2f(0.41,0.04);
	glVertex2f(0.54,0.04);
	glVertex2f(0.54,-0.04);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.55,-0.04);
	glVertex2f(0.55,0.04);
	glVertex2f(0.68,0.04);
	glVertex2f(0.68,-0.04);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.69,-0.04);
	glVertex2f(0.69,0.04);
	glVertex2f(0.82,0.04);
	glVertex2f(0.82,-0.04);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.83,-0.04);
	glVertex2f(0.83,0.04);
	glVertex2f(0.95,0.04);
	glVertex2f(0.95,-0.04);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.96,-0.04);
	glVertex2f(0.96,0.04);
	glVertex2f(1.0,0.04);
	glVertex2f(1.0,-0.04);
    glEnd();



    //2
	glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.01,-0.04);
	glVertex2f(-0.01,0.04);
	glVertex2f(-0.13,0.04);
	glVertex2f(-0.13,-0.04);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.14,-0.04);
	glVertex2f(-0.14,0.04);
	glVertex2f(-0.26,0.04);
	glVertex2f(-0.26,-0.04);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.27,-0.04);
	glVertex2f(-0.27,0.04);
	glVertex2f(-0.40,0.04);
	glVertex2f(-0.40,-0.04);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.41,-0.04);
	glVertex2f(-0.41,0.04);
	glVertex2f(-0.54,0.04);
	glVertex2f(-0.54,-0.04);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.55,-0.04);
	glVertex2f(-0.55,0.04);
	glVertex2f(-0.68,0.04);
	glVertex2f(-0.68,-0.04);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.69,-0.04);
	glVertex2f(-0.69,0.04);
	glVertex2f(-0.82,0.04);
	glVertex2f(-0.82,-0.04);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.83,-0.04);
	glVertex2f(-0.83,0.04);
	glVertex2f(-0.95,0.04);
	glVertex2f(-0.95,-0.04);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.96,-0.04);
	glVertex2f(-0.96,0.04);
	glVertex2f(-1.0,0.04);
	glVertex2f(-1.0,-0.04);
    glEnd();



    glPushMatrix();



    //1stQua
    //Column0
    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.01,0.05);
	glVertex2f(0.01,0.11);
	glVertex2f(0.06,0.11);
	glVertex2f(0.06,0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.07,0.05);
	glVertex2f(0.07,0.11);
	glVertex2f(0.13,0.11);
	glVertex2f(0.13,0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.14,0.05);
	glVertex2f(0.14,0.11);
	glVertex2f(0.19,0.11);
	glVertex2f(0.19,0.05);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.20,0.05);
	glVertex2f(0.20,0.11);
	glVertex2f(0.26,0.11);
	glVertex2f(0.26,0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.27,0.05);
	glVertex2f(0.27,0.11);
	glVertex2f(0.33,0.11);
	glVertex2f(0.33,0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.34,0.05);
	glVertex2f(0.34,0.11);
	glVertex2f(0.40,0.11);
	glVertex2f(0.40,0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.41,0.05);
	glVertex2f(0.41,0.11);
	glVertex2f(0.47,0.11);
	glVertex2f(0.47,0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.48,0.05);
	glVertex2f(0.48,0.11);
	glVertex2f(0.54,0.11);
	glVertex2f(0.54,0.05);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.55,0.05);
	glVertex2f(0.55,0.11);
	glVertex2f(0.61,0.11);
	glVertex2f(0.61,0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.62,0.05);
	glVertex2f(0.62,0.11);
	glVertex2f(0.68,0.11);
	glVertex2f(0.68,0.05);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.69,0.05);
	glVertex2f(0.69,0.11);
	glVertex2f(0.75,0.11);
	glVertex2f(0.75,0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.76,0.05);
	glVertex2f(0.76,0.11);
	glVertex2f(0.82,0.11);
	glVertex2f(0.82,0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.83,0.05);
	glVertex2f(0.83,0.11);
	glVertex2f(0.89,0.11);
	glVertex2f(0.89,0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.90,0.05);
	glVertex2f(0.90,0.11);
	glVertex2f(0.95,0.11);
	glVertex2f(0.95,0.05);
    glEnd();

    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.96,0.05);
	glVertex2f(0.96,0.11);
	glVertex2f(1.0,0.11);
	glVertex2f(1.0,0.05);
    glEnd();

    //Column1
	glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.01,0.12);
	glVertex2f(0.01,0.18);
	glVertex2f(0.13,0.18);
	glVertex2f(0.13,0.12);
    glEnd();

    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.14,0.12);
	glVertex2f(0.14,0.18);
	glVertex2f(0.26,0.18);
	glVertex2f(0.26,0.12);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.27,0.12);
	glVertex2f(0.27,0.18);
	glVertex2f(0.40,0.18);
	glVertex2f(0.40,0.12);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.41,0.12);
	glVertex2f(0.41,0.18);
	glVertex2f(0.54,0.18);
	glVertex2f(0.54,0.12);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.55,0.12);
	glVertex2f(0.55,0.18);
	glVertex2f(0.68,0.18);
	glVertex2f(0.68,0.12);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.69,0.12);
	glVertex2f(0.69,0.18);
	glVertex2f(0.82,0.18);
	glVertex2f(0.82,0.12);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.83,0.12);
	glVertex2f(0.83,0.18);
	glVertex2f(0.95,0.18);
	glVertex2f(0.95,0.12);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.96,0.12);
	glVertex2f(0.96,0.18);
	glVertex2f(1.0,0.18);
	glVertex2f(1.0,0.12);
    glEnd();




    //Column2
    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.01,0.19);
	glVertex2f(0.01,0.25);
	glVertex2f(0.06,0.25);
	glVertex2f(0.06,0.19);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.07,0.19);
	glVertex2f(0.07,0.25);
	glVertex2f(0.13,0.25);
	glVertex2f(0.13,0.19);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.14,0.19);
	glVertex2f(0.14,0.25);
	glVertex2f(0.19,0.25);
	glVertex2f(0.19,0.19);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.20,0.19);
	glVertex2f(0.20,0.25);
	glVertex2f(0.26,0.25);
	glVertex2f(0.26,0.19);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.27,0.19);
	glVertex2f(0.27,0.25);
	glVertex2f(0.33,0.25);
	glVertex2f(0.33,0.19);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.34,0.19);
	glVertex2f(0.34,0.25);
	glVertex2f(0.40,0.25);
	glVertex2f(0.40,0.19);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.41,0.19);
	glVertex2f(0.41,0.25);
	glVertex2f(0.47,0.25);
	glVertex2f(0.47,0.19);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.48,0.19);
	glVertex2f(0.48,0.25);
	glVertex2f(0.54,0.25);
	glVertex2f(0.54,0.19);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.55,0.19);
	glVertex2f(0.55,0.25);
	glVertex2f(0.61,0.25);
	glVertex2f(0.61,0.19);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.62,0.19);
	glVertex2f(0.62,0.25);
	glVertex2f(0.68,0.25);
	glVertex2f(0.68,0.19);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.69,0.19);
	glVertex2f(0.69,0.25);
	glVertex2f(0.75,0.25);
	glVertex2f(0.75,0.19);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.76,0.19);
	glVertex2f(0.76,0.25);
	glVertex2f(0.82,0.25);
	glVertex2f(0.82,0.19);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.83,0.19);
	glVertex2f(0.83,0.25);
	glVertex2f(0.89,0.25);
	glVertex2f(0.89,0.19);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.90,0.19);
	glVertex2f(0.90,0.25);
	glVertex2f(0.95,0.25);
	glVertex2f(0.95,0.19);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.96,0.19);
	glVertex2f(0.96,0.25);
	glVertex2f(1.0,0.25);
	glVertex2f(1.0,0.19);
    glEnd();



    //Column3
	glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.01,0.26);
	glVertex2f(0.01,0.31);
	glVertex2f(0.13,0.31);
	glVertex2f(0.13,0.26);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.14,0.26);
	glVertex2f(0.14,0.31);
	glVertex2f(0.26,0.31);
	glVertex2f(0.26,0.26);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.27,0.26);
	glVertex2f(0.27,0.31);
	glVertex2f(0.40,0.31);
	glVertex2f(0.40,0.26);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.41,0.26);
	glVertex2f(0.41,0.31);
	glVertex2f(0.54,0.31);
	glVertex2f(0.54,0.26);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.55,0.26);
	glVertex2f(0.55,0.31);
	glVertex2f(0.68,0.31);
	glVertex2f(0.68,0.26);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.69,0.26);
	glVertex2f(0.69,0.31);
	glVertex2f(0.82,0.31);
	glVertex2f(0.82,0.26);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.83,0.26);
	glVertex2f(0.83,0.31);
	glVertex2f(0.95,0.31);
	glVertex2f(0.95,0.26);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.96,0.26);
	glVertex2f(0.96,0.31);
	glVertex2f(1.0,0.31);
	glVertex2f(1.0,0.26);
    glEnd();




    //Column4
    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.01,0.32);
	glVertex2f(0.01,0.38);
	glVertex2f(0.06,0.38);
	glVertex2f(0.06,0.32);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.07,0.32);
	glVertex2f(0.07,0.38);
	glVertex2f(0.13,0.38);
	glVertex2f(0.13,0.32);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.14,0.32);
	glVertex2f(0.14,0.38);
	glVertex2f(0.19,0.38);
	glVertex2f(0.19,0.32);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.20,0.32);
	glVertex2f(0.20,0.38);
	glVertex2f(0.26,0.38);
	glVertex2f(0.26,0.32);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.27,0.32);
	glVertex2f(0.27,0.38);
	glVertex2f(0.33,0.38);
	glVertex2f(0.33,0.32);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.34,0.32);
	glVertex2f(0.34,0.38);
	glVertex2f(0.40,0.38);
	glVertex2f(0.40,0.32);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.41,0.32);
	glVertex2f(0.41,0.38);
	glVertex2f(0.47,0.38);
	glVertex2f(0.47,0.32);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.48,0.32);
	glVertex2f(0.48,0.38);
	glVertex2f(0.54,0.38);
	glVertex2f(0.54,0.32);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.55,0.32);
	glVertex2f(0.55,0.38);
	glVertex2f(0.61,0.38);
	glVertex2f(0.61,0.32);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.62,0.32);
	glVertex2f(0.62,0.38);
	glVertex2f(0.68,0.38);
	glVertex2f(0.68,0.32);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.69,0.32);
	glVertex2f(0.69,0.38);
	glVertex2f(0.75,0.38);
	glVertex2f(0.75,0.32);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.76,0.32);
	glVertex2f(0.76,0.38);
	glVertex2f(0.82,0.38);
	glVertex2f(0.82,0.32);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.83,0.32);
	glVertex2f(0.83,0.38);
	glVertex2f(0.89,0.38);
	glVertex2f(0.89,0.32);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.90,0.32);
	glVertex2f(0.90,0.38);
	glVertex2f(0.95,0.38);
	glVertex2f(0.95,0.32);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.96,0.32);
	glVertex2f(0.96,0.38);
	glVertex2f(1.0,0.38);
	glVertex2f(1.0,0.32);
    glEnd();




    //Column5
	glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.01,0.39);
	glVertex2f(0.01,0.45);
	glVertex2f(0.13,0.45);
	glVertex2f(0.13,0.39);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.14,0.39);
	glVertex2f(0.14,0.45);
	glVertex2f(0.26,0.45);
	glVertex2f(0.26,0.39);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.27,0.39);
	glVertex2f(0.27,0.45);
	glVertex2f(0.40,0.45);
	glVertex2f(0.40,0.39);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.41,0.39);
	glVertex2f(0.41,0.45);
	glVertex2f(0.54,0.45);
	glVertex2f(0.54,0.39);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.55,0.39);
	glVertex2f(0.55,0.45);
	glVertex2f(0.68,0.45);
	glVertex2f(0.68,0.39);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.69,0.39);
	glVertex2f(0.69,0.45);
	glVertex2f(0.82,0.45);
	glVertex2f(0.82,0.39);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.83,0.39);
	glVertex2f(0.83,0.45);
	glVertex2f(0.95,0.45);
	glVertex2f(0.95,0.39);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.96,0.39);
	glVertex2f(0.96,0.45);
	glVertex2f(1.0,0.45);
	glVertex2f(1.0,0.39);
    glEnd();




    //Column6
    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.01,0.46);
	glVertex2f(0.01,0.52);
	glVertex2f(0.06,0.52);
	glVertex2f(0.06,0.46);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.07,0.46);
	glVertex2f(0.07,0.52);
	glVertex2f(0.13,0.52);
	glVertex2f(0.13,0.46);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.14,0.46);
	glVertex2f(0.14,0.52);
	glVertex2f(0.19,0.52);
	glVertex2f(0.19,0.46);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.20,0.46);
	glVertex2f(0.20,0.52);
	glVertex2f(0.26,0.52);
	glVertex2f(0.26,0.46);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.27,0.46);
	glVertex2f(0.27,0.52);
	glVertex2f(0.33,0.52);
	glVertex2f(0.33,0.46);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.34,0.46);
	glVertex2f(0.34,0.52);
	glVertex2f(0.40,0.52);
	glVertex2f(0.40,0.46);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.41,0.46);
	glVertex2f(0.41,0.52);
	glVertex2f(0.47,0.52);
	glVertex2f(0.47,0.46);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.48,0.46);
	glVertex2f(0.48,0.52);
	glVertex2f(0.54,0.52);
	glVertex2f(0.54,0.46);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.55,0.46);
	glVertex2f(0.55,0.52);
	glVertex2f(0.61,0.52);
	glVertex2f(0.61,0.46);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.62,0.46);
	glVertex2f(0.62,0.52);
	glVertex2f(0.68,0.52);
	glVertex2f(0.68,0.46);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.69,0.46);
	glVertex2f(0.69,0.52);
	glVertex2f(0.75,0.52);
	glVertex2f(0.75,0.46);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.76,0.46);
	glVertex2f(0.76,0.52);
	glVertex2f(0.82,0.52);
	glVertex2f(0.82,0.46);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.83,0.46);
	glVertex2f(0.83,0.52);
	glVertex2f(0.89,0.52);
	glVertex2f(0.89,0.46);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.90,0.46);
	glVertex2f(0.90,0.52);
	glVertex2f(0.95,0.52);
	glVertex2f(0.95,0.46);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.96,0.46);
	glVertex2f(0.96,0.52);
	glVertex2f(1.0,0.52);
	glVertex2f(1.0,0.46);
    glEnd();




    //Column7
	glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.01,0.53);
	glVertex2f(0.01,0.59);
	glVertex2f(0.13,0.59);
	glVertex2f(0.13,0.53);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.14,0.53);
	glVertex2f(0.14,0.59);
	glVertex2f(0.26,0.59);
	glVertex2f(0.26,0.53);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.27,0.53);
	glVertex2f(0.27,0.59);
	glVertex2f(0.40,0.59);
	glVertex2f(0.40,0.53);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.41,0.53);
	glVertex2f(0.41,0.59);
	glVertex2f(0.54,0.59);
	glVertex2f(0.54,0.53);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.55,0.53);
	glVertex2f(0.55,0.59);
	glVertex2f(0.68,0.59);
	glVertex2f(0.68,0.53);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.69,0.53);
	glVertex2f(0.69,0.59);
	glVertex2f(0.82,0.59);
	glVertex2f(0.82,0.53);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.83,0.53);
	glVertex2f(0.83,0.59);
	glVertex2f(0.95,0.59);
	glVertex2f(0.95,0.53);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.96,0.53);
	glVertex2f(0.96,0.59);
	glVertex2f(1.0,0.59);
	glVertex2f(1.0,0.53);
    glEnd();



    //Column8
    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.01,0.60);
	glVertex2f(0.01,0.66);
	glVertex2f(0.06,0.66);
	glVertex2f(0.06,0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.07,0.60);
	glVertex2f(0.07,0.66);
	glVertex2f(0.13,0.66);
	glVertex2f(0.13,0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.14,0.60);
	glVertex2f(0.14,0.66);
	glVertex2f(0.19,0.66);
	glVertex2f(0.19,0.60);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.20,0.60);
	glVertex2f(0.20,0.66);
	glVertex2f(0.26,0.66);
	glVertex2f(0.26,0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.27,0.60);
	glVertex2f(0.27,0.66);
	glVertex2f(0.33,0.66);
	glVertex2f(0.33,0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.34,0.60);
	glVertex2f(0.34,0.66);
	glVertex2f(0.40,0.66);
	glVertex2f(0.40,0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.41,0.60);
	glVertex2f(0.41,0.66);
	glVertex2f(0.47,0.66);
	glVertex2f(0.47,0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.48,0.60);
	glVertex2f(0.48,0.66);
	glVertex2f(0.54,0.66);
	glVertex2f(0.54,0.60);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.55,0.60);
	glVertex2f(0.55,0.66);
	glVertex2f(0.61,0.66);
	glVertex2f(0.61,0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.62,0.60);
	glVertex2f(0.62,0.66);
	glVertex2f(0.68,0.66);
	glVertex2f(0.68,0.60);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.69,0.60);
	glVertex2f(0.69,0.66);
	glVertex2f(0.75,0.66);
	glVertex2f(0.75,0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.76,0.60);
	glVertex2f(0.76,0.66);
	glVertex2f(0.82,0.66);
	glVertex2f(0.82,0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.83,0.60);
	glVertex2f(0.83,0.66);
	glVertex2f(0.89,0.66);
	glVertex2f(0.89,0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.90,0.60);
	glVertex2f(0.90,0.66);
	glVertex2f(0.95,0.66);
	glVertex2f(0.95,0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.96,0.60);
	glVertex2f(0.96,0.66);
	glVertex2f(1.0,0.66);
	glVertex2f(1.0,0.60);
    glEnd();



    //Column9
	glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.01,0.67);
	glVertex2f(0.01,0.73);
	glVertex2f(0.13,0.73);
	glVertex2f(0.13,0.67);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.14,0.67);
	glVertex2f(0.14,0.73);
	glVertex2f(0.26,0.73);
	glVertex2f(0.26,0.67);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.27,0.67);
	glVertex2f(0.27,0.73);
	glVertex2f(0.40,0.73);
	glVertex2f(0.40,0.67);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.41,0.67);
	glVertex2f(0.41,0.73);
	glVertex2f(0.54,0.73);
	glVertex2f(0.54,0.67);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.55,0.67);
	glVertex2f(0.55,0.73);
	glVertex2f(0.68,0.73);
	glVertex2f(0.68,0.67);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.69,0.67);
	glVertex2f(0.69,0.73);
	glVertex2f(0.82,0.73);
	glVertex2f(0.82,0.67);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.83,0.67);
	glVertex2f(0.83,0.73);
	glVertex2f(0.95,0.73);
	glVertex2f(0.95,0.67);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.96,0.67);
	glVertex2f(0.96,0.73);
	glVertex2f(1.0,0.73);
	glVertex2f(1.0,0.67);
    glEnd();


    //Column10
    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.01,0.74);
	glVertex2f(0.01,0.80);
	glVertex2f(0.06,0.80);
	glVertex2f(0.06,0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.07,0.74);
	glVertex2f(0.07,0.80);
	glVertex2f(0.13,0.80);
	glVertex2f(0.13,0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.14,0.74);
	glVertex2f(0.14,0.80);
	glVertex2f(0.19,0.80);
	glVertex2f(0.19,0.74);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.20,0.74);
	glVertex2f(0.20,0.80);
	glVertex2f(0.26,0.80);
	glVertex2f(0.26,0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.27,0.74);
	glVertex2f(0.27,0.80);
	glVertex2f(0.33,0.80);
	glVertex2f(0.33,0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.34,0.74);
	glVertex2f(0.34,0.80);
	glVertex2f(0.40,0.80);
	glVertex2f(0.40,0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.41,0.74);
	glVertex2f(0.41,0.80);
	glVertex2f(0.47,0.80);
	glVertex2f(0.47,0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.48,0.74);
	glVertex2f(0.48,0.80);
	glVertex2f(0.54,0.80);
	glVertex2f(0.54,0.74);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.55,0.74);
	glVertex2f(0.55,0.80);
	glVertex2f(0.61,0.80);
	glVertex2f(0.61,0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.62,0.74);
	glVertex2f(0.62,0.80);
	glVertex2f(0.68,0.80);
	glVertex2f(0.68,0.74);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.69,0.74);
	glVertex2f(0.69,0.80);
	glVertex2f(0.75,0.80);
	glVertex2f(0.75,0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.76,0.74);
	glVertex2f(0.76,0.80);
	glVertex2f(0.82,0.80);
	glVertex2f(0.82,0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.83,0.74);
	glVertex2f(0.83,0.80);
	glVertex2f(0.89,0.80);
	glVertex2f(0.89,0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.90,0.74);
	glVertex2f(0.90,0.80);
	glVertex2f(0.95,0.80);
	glVertex2f(0.95,0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.96,0.74);
	glVertex2f(0.96,0.80);
	glVertex2f(1.0,0.80);
	glVertex2f(1.0,0.74);
    glEnd();



    //Colum11
	glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.01,0.81);
	glVertex2f(0.01,0.87);
	glVertex2f(0.13,0.87);
	glVertex2f(0.13,0.81);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.14,0.81);
	glVertex2f(0.14,0.87);
	glVertex2f(0.26,0.87);
	glVertex2f(0.26,0.81);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.27,0.81);
	glVertex2f(0.27,0.87);
	glVertex2f(0.40,0.87);
	glVertex2f(0.40,0.81);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.41,0.81);
	glVertex2f(0.41,0.87);
	glVertex2f(0.54,0.87);
	glVertex2f(0.54,0.81);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.55,0.81);
	glVertex2f(0.55,0.87);
	glVertex2f(0.68,0.87);
	glVertex2f(0.68,0.81);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.69,0.81);
	glVertex2f(0.69,0.87);
	glVertex2f(0.82,0.87);
	glVertex2f(0.82,0.81);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.83,0.81);
	glVertex2f(0.83,0.87);
	glVertex2f(0.95,0.87);
	glVertex2f(0.95,0.81);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.96,0.81);
	glVertex2f(0.96,0.87);
	glVertex2f(1.0,0.87);
	glVertex2f(1.0,0.81);
    glEnd();




    //Column12
    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.01,0.88);
	glVertex2f(0.01,0.94);
	glVertex2f(0.06,0.94);
	glVertex2f(0.06,0.88);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.07,0.88);
	glVertex2f(0.07,0.94);
	glVertex2f(0.13,0.94);
	glVertex2f(0.13,0.88);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.14,0.88);
	glVertex2f(0.14,0.94);
	glVertex2f(0.19,0.94);
	glVertex2f(0.19,0.88);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.20,0.88);
	glVertex2f(0.20,0.94);
	glVertex2f(0.26,0.94);
	glVertex2f(0.26,0.88);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.27,0.94);
	glVertex2f(0.27,0.88);
	glVertex2f(0.33,0.88);
	glVertex2f(0.33,0.94);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.34,0.94);
	glVertex2f(0.34,0.88);
	glVertex2f(0.40,0.88);
	glVertex2f(0.40,0.94);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.41,0.94);
	glVertex2f(0.41,0.88);
	glVertex2f(0.47,0.88);
	glVertex2f(0.47,0.94);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.48,0.94);
	glVertex2f(0.48,0.88);
	glVertex2f(0.54,0.88);
	glVertex2f(0.54,0.94);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.55,0.94);
	glVertex2f(0.55,0.88);
	glVertex2f(0.61,0.88);
	glVertex2f(0.61,0.94);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.62,0.94);
	glVertex2f(0.62,0.88);
	glVertex2f(0.68,0.88);
	glVertex2f(0.68,0.94);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.69,0.94);
	glVertex2f(0.69,0.88);
	glVertex2f(0.75,0.88);
	glVertex2f(0.75,0.94);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.76,0.94);
	glVertex2f(0.76,0.88);
	glVertex2f(0.82,0.88);
	glVertex2f(0.82,0.94);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.83,0.94);
	glVertex2f(0.83,0.88);
	glVertex2f(0.89,0.88);
	glVertex2f(0.89,0.94);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.90,0.94);
	glVertex2f(0.90,0.88);
	glVertex2f(0.95,0.88);
	glVertex2f(0.95,0.94);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.96,0.94);
	glVertex2f(0.96,0.88);
	glVertex2f(1.0,0.88);
	glVertex2f(1.0,0.94);
    glEnd();





    //2ndQua
    //Column0
    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.01,-0.05);
	glVertex2f(0.01,-0.11);
	glVertex2f(0.06,-0.11);
	glVertex2f(0.06,-0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.07,-0.05);
	glVertex2f(0.07,-0.11);
	glVertex2f(0.13,-0.11);
	glVertex2f(0.13,-0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.14,-0.05);
	glVertex2f(0.14,-0.11);
	glVertex2f(0.19,-0.11);
	glVertex2f(0.19,-0.05);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.20,-0.05);
	glVertex2f(0.20,-0.11);
	glVertex2f(0.26,-0.11);
	glVertex2f(0.26,-0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.27,-0.05);
	glVertex2f(0.27,-0.11);
	glVertex2f(0.33,-0.11);
	glVertex2f(0.33,-0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.34,-0.05);
	glVertex2f(0.34,-0.11);
	glVertex2f(0.40,-0.11);
	glVertex2f(0.40,-0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.41,-0.05);
	glVertex2f(0.41,-0.11);
	glVertex2f(0.47,-0.11);
	glVertex2f(0.47,-0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.48,-0.05);
	glVertex2f(0.48,-0.11);
	glVertex2f(0.54,-0.11);
	glVertex2f(0.54,-0.05);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.55,-0.05);
	glVertex2f(0.55,-0.11);
	glVertex2f(0.61,-0.11);
	glVertex2f(0.61,-0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.62,-0.05);
	glVertex2f(0.62,-0.11);
	glVertex2f(0.68,-0.11);
	glVertex2f(0.68,-0.05);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.69,-0.05);
	glVertex2f(0.69,-0.11);
	glVertex2f(0.75,-0.11);
	glVertex2f(0.75,-0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.76,-0.05);
	glVertex2f(0.76,-0.11);
	glVertex2f(0.82,-0.11);
	glVertex2f(0.82,-0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.83,-0.05);
	glVertex2f(0.83,-0.11);
	glVertex2f(0.89,-0.11);
	glVertex2f(0.89,-0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.90,-0.05);
	glVertex2f(0.90,-0.11);
	glVertex2f(0.95,-0.11);
	glVertex2f(0.95,-0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.96,-0.05);
	glVertex2f(0.96,-0.11);
	glVertex2f(1.0,-0.11);
	glVertex2f(1.0,-0.05);
    glEnd();



    //Column1
	glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.01,-0.12);
	glVertex2f(0.01,-0.18);
	glVertex2f(0.13,-0.18);
	glVertex2f(0.13,-0.12);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.14,-0.12);
	glVertex2f(0.14,-0.18);
	glVertex2f(0.26,-0.18);
	glVertex2f(0.26,-0.12);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.27,-0.12);
	glVertex2f(0.27,-0.18);
	glVertex2f(0.40,-0.18);
	glVertex2f(0.40,-0.12);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.41,-0.12);
	glVertex2f(0.41,-0.18);
	glVertex2f(0.54,-0.18);
	glVertex2f(0.54,-0.12);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.55,-0.12);
	glVertex2f(0.55,-0.18);
	glVertex2f(0.68,-0.18);
	glVertex2f(0.68,-0.12);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.69,-0.12);
	glVertex2f(0.69,-0.18);
	glVertex2f(0.82,-0.18);
	glVertex2f(0.82,-0.12);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.83,-0.12);
	glVertex2f(0.83,-0.18);
	glVertex2f(0.95,-0.18);
	glVertex2f(0.95,-0.12);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.96,-0.12);
	glVertex2f(0.96,-0.18);
	glVertex2f(1.0,-0.18);
	glVertex2f(1.0,-0.12);
    glEnd();




    //Column2
    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.01,-0.19);
	glVertex2f(0.01,-0.25);
	glVertex2f(0.06,-0.25);
	glVertex2f(0.06,-0.19);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.07,-0.19);
	glVertex2f(0.07,-0.25);
	glVertex2f(0.13,-0.25);
	glVertex2f(0.13,-0.19);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.14,-0.19);
	glVertex2f(0.14,-0.25);
	glVertex2f(0.19,-0.25);
	glVertex2f(0.19,-0.19);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.20,-0.19);
	glVertex2f(0.20,-0.25);
	glVertex2f(0.26,-0.25);
	glVertex2f(0.26,-0.19);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.27,-0.19);
	glVertex2f(0.27,-0.25);
	glVertex2f(0.33,-0.25);
	glVertex2f(0.33,-0.19);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.34,-0.19);
	glVertex2f(0.34,-0.25);
	glVertex2f(0.40,-0.25);
	glVertex2f(0.40,-0.19);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.41,-0.19);
	glVertex2f(0.41,-0.25);
	glVertex2f(0.47,-0.25);
	glVertex2f(0.47,-0.19);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.48,-0.19);
	glVertex2f(0.48,-0.25);
	glVertex2f(0.54,-0.25);
	glVertex2f(0.54,-0.19);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.55,-0.19);
	glVertex2f(0.55,-0.25);
	glVertex2f(0.61,-0.25);
	glVertex2f(0.61,-0.19);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.62,-0.19);
	glVertex2f(0.62,-0.25);
	glVertex2f(0.68,-0.25);
	glVertex2f(0.68,-0.19);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.69,-0.19);
	glVertex2f(0.69,-0.25);
	glVertex2f(0.75,-0.25);
	glVertex2f(0.75,-0.19);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.76,-0.19);
	glVertex2f(0.76,-0.25);
	glVertex2f(0.82,-0.25);
	glVertex2f(0.82,-0.19);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.83,-0.19);
	glVertex2f(0.83,-0.25);
	glVertex2f(0.89,-0.25);
	glVertex2f(0.89,-0.19);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.90,-0.19);
	glVertex2f(0.90,-0.25);
	glVertex2f(0.95,-0.25);
	glVertex2f(0.95,-0.19);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.96,-0.19);
	glVertex2f(0.96,-0.25);
	glVertex2f(1.0,-0.25);
	glVertex2f(1.0,-0.19);
    glEnd();



    //Column3
	glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.01,-0.26);
	glVertex2f(0.01,-0.31);
	glVertex2f(0.13,-0.31);
	glVertex2f(0.13,-0.26);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.14,-0.26);
	glVertex2f(0.14,-0.31);
	glVertex2f(0.26,-0.31);
	glVertex2f(0.26,-0.26);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.27,-0.26);
	glVertex2f(0.27,-0.31);
	glVertex2f(0.40,-0.31);
	glVertex2f(0.40,-0.26);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.41,-0.26);
	glVertex2f(0.41,-0.31);
	glVertex2f(0.54,-0.31);
	glVertex2f(0.54,-0.26);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.55,-0.26);
	glVertex2f(0.55,-0.31);
	glVertex2f(0.68,-0.31);
	glVertex2f(0.68,-0.26);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.69,-0.26);
	glVertex2f(0.69,-0.31);
	glVertex2f(0.82,-0.31);
	glVertex2f(0.82,-0.26);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.83,-0.26);
	glVertex2f(0.83,-0.31);
	glVertex2f(0.95,-0.31);
	glVertex2f(0.95,-0.26);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.96,-0.26);
	glVertex2f(0.96,-0.31);
	glVertex2f(1.0,-0.31);
	glVertex2f(1.0,-0.26);
    glEnd();




    //Column4
    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.01,-0.32);
	glVertex2f(0.01,-0.38);
	glVertex2f(0.06,-0.38);
	glVertex2f(0.06,-0.32);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.07,-0.32);
	glVertex2f(0.07,-0.38);
	glVertex2f(0.13,-0.38);
	glVertex2f(0.13,-0.32);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.14,-0.32);
	glVertex2f(0.14,-0.38);
	glVertex2f(0.19,-0.38);
	glVertex2f(0.19,-0.32);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.20,-0.32);
	glVertex2f(0.20,-0.38);
	glVertex2f(0.26,-0.38);
	glVertex2f(0.26,-0.32);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.27,-0.32);
	glVertex2f(0.27,-0.38);
	glVertex2f(0.33,-0.38);
	glVertex2f(0.33,-0.32);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.34,-0.32);
	glVertex2f(0.34,-0.38);
	glVertex2f(0.40,-0.38);
	glVertex2f(0.40,-0.32);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.41,-0.32);
	glVertex2f(0.41,-0.38);
	glVertex2f(0.47,-0.38);
	glVertex2f(0.47,-0.32);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.48,-0.32);
	glVertex2f(0.48,-0.38);
	glVertex2f(0.54,-0.38);
	glVertex2f(0.54,-0.32);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.55,-0.32);
	glVertex2f(0.55,-0.38);
	glVertex2f(0.61,-0.38);
	glVertex2f(0.61,-0.32);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.62,-0.32);
	glVertex2f(0.62,-0.38);
	glVertex2f(0.68,-0.38);
	glVertex2f(0.68,-0.32);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.69,-0.32);
	glVertex2f(0.69,-0.38);
	glVertex2f(0.75,-0.38);
	glVertex2f(0.75,-0.32);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.76,-0.32);
	glVertex2f(0.76,-0.38);
	glVertex2f(0.82,-0.38);
	glVertex2f(0.82,-0.32);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.83,-0.32);
	glVertex2f(0.83,-0.38);
	glVertex2f(0.89,-0.38);
	glVertex2f(0.89,-0.32);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.90,-0.32);
	glVertex2f(0.90,-0.38);
	glVertex2f(0.95,-0.38);
	glVertex2f(0.95,-0.32);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.96,-0.32);
	glVertex2f(0.96,-0.38);
	glVertex2f(1.0,-0.38);
	glVertex2f(1.0,-0.32);
    glEnd();




    //Column5
	glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.01,-0.39);
	glVertex2f(0.01,-0.45);
	glVertex2f(0.13,-0.45);
	glVertex2f(0.13,-0.39);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.14,-0.39);
	glVertex2f(0.14,-0.45);
	glVertex2f(0.26,-0.45);
	glVertex2f(0.26,-0.39);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.27,-0.39);
	glVertex2f(0.27,-0.45);
	glVertex2f(0.40,-0.45);
	glVertex2f(0.40,-0.39);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.41,-0.39);
	glVertex2f(0.41,-0.45);
	glVertex2f(0.54,-0.45);
	glVertex2f(0.54,-0.39);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.55,-0.39);
	glVertex2f(0.55,-0.45);
	glVertex2f(0.68,-0.45);
	glVertex2f(0.68,-0.39);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.69,-0.39);
	glVertex2f(0.69,-0.45);
	glVertex2f(0.82,-0.45);
	glVertex2f(0.82,-0.39);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.83,-0.39);
	glVertex2f(0.83,-0.45);
	glVertex2f(0.95,-0.45);
	glVertex2f(0.95,-0.39);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.96,-0.39);
	glVertex2f(0.96,-0.45);
	glVertex2f(1.0,-0.45);
	glVertex2f(1.0,-0.39);
    glEnd();




    //Column6
    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.01,-0.46);
	glVertex2f(0.01,-0.52);
	glVertex2f(0.06,-0.52);
	glVertex2f(0.06,-0.46);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.07,-0.46);
	glVertex2f(0.07,-0.52);
	glVertex2f(0.13,-0.52);
	glVertex2f(0.13,-0.46);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.14,-0.46);
	glVertex2f(0.14,-0.52);
	glVertex2f(0.19,-0.52);
	glVertex2f(0.19,-0.46);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.20,-0.46);
	glVertex2f(0.20,-0.52);
	glVertex2f(0.26,-0.52);
	glVertex2f(0.26,-0.46);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.27,-0.46);
	glVertex2f(0.27,-0.52);
	glVertex2f(0.33,-0.52);
	glVertex2f(0.33,-0.46);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.34,-0.46);
	glVertex2f(0.34,-0.52);
	glVertex2f(0.40,-0.52);
	glVertex2f(0.40,-0.46);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.41,-0.46);
	glVertex2f(0.41,-0.52);
	glVertex2f(0.47,-0.52);
	glVertex2f(0.47,-0.46);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.48,-0.46);
	glVertex2f(0.48,-0.52);
	glVertex2f(0.54,-0.52);
	glVertex2f(0.54,-0.46);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.55,-0.46);
	glVertex2f(0.55,-0.52);
	glVertex2f(0.61,-0.52);
	glVertex2f(0.61,-0.46);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.62,-0.46);
	glVertex2f(0.62,-0.52);
	glVertex2f(0.68,-0.52);
	glVertex2f(0.68,-0.46);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.69,-0.46);
	glVertex2f(0.69,-0.52);
	glVertex2f(0.75,-0.52);
	glVertex2f(0.75,-0.46);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.76,-0.46);
	glVertex2f(0.76,-0.52);
	glVertex2f(0.82,-0.52);
	glVertex2f(0.82,-0.46);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.83,-0.46);
	glVertex2f(0.83,-0.52);
	glVertex2f(0.89,-0.52);
	glVertex2f(0.89,-0.46);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.90,-0.46);
	glVertex2f(0.90,-0.52);
	glVertex2f(0.95,-0.52);
	glVertex2f(0.95,-0.46);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.96,-0.46);
	glVertex2f(0.96,-0.52);
	glVertex2f(1.0,-0.52);
	glVertex2f(1.0,-0.46);
    glEnd();




    //Column7
	glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.01,-0.53);
	glVertex2f(0.01,-0.59);
	glVertex2f(0.13,-0.59);
	glVertex2f(0.13,-0.53);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.14,-0.53);
	glVertex2f(0.14,-0.59);
	glVertex2f(0.26,-0.59);
	glVertex2f(0.26,-0.53);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.27,-0.53);
	glVertex2f(0.27,-0.59);
	glVertex2f(0.40,-0.59);
	glVertex2f(0.40,-0.53);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.41,-0.53);
	glVertex2f(0.41,-0.59);
	glVertex2f(0.54,-0.59);
	glVertex2f(0.54,-0.53);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.55,-0.53);
	glVertex2f(0.55,-0.59);
	glVertex2f(0.68,-0.59);
	glVertex2f(0.68,-0.53);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.69,-0.53);
	glVertex2f(0.69,-0.59);
	glVertex2f(0.82,-0.59);
	glVertex2f(0.82,-0.53);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.83,-0.53);
	glVertex2f(0.83,-0.59);
	glVertex2f(0.95,-0.59);
	glVertex2f(0.95,-0.53);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.96,-0.53);
	glVertex2f(0.96,-0.59);
	glVertex2f(1.0,-0.59);
	glVertex2f(1.0,-0.53);
    glEnd();



    //Column8
    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.01,-0.60);
	glVertex2f(0.01,-0.66);
	glVertex2f(0.06,-0.66);
	glVertex2f(0.06,-0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.07,-0.60);
	glVertex2f(0.07,-0.66);
	glVertex2f(0.13,-0.66);
	glVertex2f(0.13,-0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.14,-0.60);
	glVertex2f(0.14,-0.66);
	glVertex2f(0.19,-0.66);
	glVertex2f(0.19,-0.60);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.20,-0.60);
	glVertex2f(0.20,-0.66);
	glVertex2f(0.26,-0.66);
	glVertex2f(0.26,-0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.27,-0.60);
	glVertex2f(0.27,-0.66);
	glVertex2f(0.33,-0.66);
	glVertex2f(0.33,-0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.34,-0.60);
	glVertex2f(0.34,-0.66);
	glVertex2f(0.40,-0.66);
	glVertex2f(0.40,-0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.41,-0.60);
	glVertex2f(0.41,-0.66);
	glVertex2f(0.47,-0.66);
	glVertex2f(0.47,-0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.48,-0.60);
	glVertex2f(0.48,-0.66);
	glVertex2f(0.54,-0.66);
	glVertex2f(0.54,-0.60);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.55,-0.60);
	glVertex2f(0.55,-0.66);
	glVertex2f(0.61,-0.66);
	glVertex2f(0.61,-0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.62,-0.60);
	glVertex2f(0.62,-0.66);
	glVertex2f(0.68,-0.66);
	glVertex2f(0.68,-0.60);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.69,-0.60);
	glVertex2f(0.69,-0.66);
	glVertex2f(0.75,-0.66);
	glVertex2f(0.75,-0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.76,-0.60);
	glVertex2f(0.76,-0.66);
	glVertex2f(0.82,-0.66);
	glVertex2f(0.82,-0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.83,-0.60);
	glVertex2f(0.83,-0.66);
	glVertex2f(0.89,-0.66);
	glVertex2f(0.89,-0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.90,-0.60);
	glVertex2f(0.90,-0.66);
	glVertex2f(0.95,-0.66);
	glVertex2f(0.95,-0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.96,-0.60);
	glVertex2f(0.96,-0.66);
	glVertex2f(1.0,-0.66);
	glVertex2f(1.0,-0.60);
    glEnd();



    //Column9
	glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.01,-0.67);
	glVertex2f(0.01,-0.73);
	glVertex2f(0.13,-0.73);
	glVertex2f(0.13,-0.67);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.14,-0.67);
	glVertex2f(0.14,-0.73);
	glVertex2f(0.26,-0.73);
	glVertex2f(0.26,-0.67);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.27,-0.67);
	glVertex2f(0.27,-0.73);
	glVertex2f(0.40,-0.73);
	glVertex2f(0.40,-0.67);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.41,-0.67);
	glVertex2f(0.41,-0.73);
	glVertex2f(0.54,-0.73);
	glVertex2f(0.54,-0.67);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.55,-0.67);
	glVertex2f(0.55,-0.73);
	glVertex2f(0.68,-0.73);
	glVertex2f(0.68,-0.67);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.69,-0.67);
	glVertex2f(0.69,-0.73);
	glVertex2f(0.82,-0.73);
	glVertex2f(0.82,-0.67);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.83,-0.67);
	glVertex2f(0.83,-0.73);
	glVertex2f(0.95,-0.73);
	glVertex2f(0.95,-0.67);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.96,-0.67);
	glVertex2f(0.96,-0.73);
	glVertex2f(1.0,-0.73);
	glVertex2f(1.0,-0.67);
    glEnd();


    //Column10
    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.01,-0.74);
	glVertex2f(0.01,-0.80);
	glVertex2f(0.06,-0.80);
	glVertex2f(0.06,-0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.07,-0.74);
	glVertex2f(0.07,-0.80);
	glVertex2f(0.13,-0.80);
	glVertex2f(0.13,-0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.14,-0.74);
	glVertex2f(0.14,-0.80);
	glVertex2f(0.19,-0.80);
	glVertex2f(0.19,-0.74);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.20,-0.74);
	glVertex2f(0.20,-0.80);
	glVertex2f(0.26,-0.80);
	glVertex2f(0.26,-0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.27,-0.74);
	glVertex2f(0.27,-0.80);
	glVertex2f(0.33,-0.80);
	glVertex2f(0.33,-0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.34,-0.74);
	glVertex2f(0.34,-0.80);
	glVertex2f(0.40,-0.80);
	glVertex2f(0.40,-0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.41,-0.74);
	glVertex2f(0.41,-0.80);
	glVertex2f(0.47,-0.80);
	glVertex2f(0.47,-0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.48,-0.74);
	glVertex2f(0.48,-0.80);
	glVertex2f(0.54,-0.80);
	glVertex2f(0.54,-0.74);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.55,-0.74);
	glVertex2f(0.55,-0.80);
	glVertex2f(0.61,-0.80);
	glVertex2f(0.61,-0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.62,-0.74);
	glVertex2f(0.62,-0.80);
	glVertex2f(0.68,-0.80);
	glVertex2f(0.68,-0.74);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.69,-0.74);
	glVertex2f(0.69,-0.80);
	glVertex2f(0.75,-0.80);
	glVertex2f(0.75,-0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.76,-0.74);
	glVertex2f(0.76,-0.80);
	glVertex2f(0.82,-0.80);
	glVertex2f(0.82,-0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.83,-0.74);
	glVertex2f(0.83,-0.80);
	glVertex2f(0.89,-0.80);
	glVertex2f(0.89,-0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.90,-0.74);
	glVertex2f(0.90,-0.80);
	glVertex2f(0.95,-0.80);
	glVertex2f(0.95,-0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.96,-0.74);
	glVertex2f(0.96,-0.80);
	glVertex2f(1.0,-0.80);
	glVertex2f(1.0,-0.74);
    glEnd();



    //Colum11
	glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.01,-0.81);
	glVertex2f(0.01,-0.87);
	glVertex2f(0.13,-0.87);
	glVertex2f(0.13,-0.81);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.14,-0.81);
	glVertex2f(0.14,-0.87);
	glVertex2f(0.26,-0.87);
	glVertex2f(0.26,-0.81);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.27,-0.81);
	glVertex2f(0.27,-0.87);
	glVertex2f(0.40,-0.87);
	glVertex2f(0.40,-0.81);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.41,-0.81);
	glVertex2f(0.41,-0.87);
	glVertex2f(0.54,-0.87);
	glVertex2f(0.54,-0.81);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.55,-0.81);
	glVertex2f(0.55,-0.87);
	glVertex2f(0.68,-0.87);
	glVertex2f(0.68,-0.81);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.69,-0.81);
	glVertex2f(0.69,-0.87);
	glVertex2f(0.82,-0.87);
	glVertex2f(0.82,-0.81);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(0.83,-0.81);
	glVertex2f(0.83,-0.87);
	glVertex2f(0.95,-0.87);
	glVertex2f(0.95,-0.81);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(0.96,-0.81);
	glVertex2f(0.96,-0.87);
	glVertex2f(1.0,-0.87);
	glVertex2f(1.0,-0.81);
    glEnd();




    //Column10
    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.01,-0.88);
	glVertex2f(0.01,-0.94);
	glVertex2f(0.06,-0.94);
	glVertex2f(0.06,-0.88);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.07,-0.88);
	glVertex2f(0.07,-0.94);
	glVertex2f(0.13,-0.94);
	glVertex2f(0.13,-0.88);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.14,-0.88);
	glVertex2f(0.14,-0.94);
	glVertex2f(0.19,-0.94);
	glVertex2f(0.19,-0.88);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.20,-0.88);
	glVertex2f(0.20,-0.94);
	glVertex2f(0.26,-0.94);
	glVertex2f(0.26,-0.88);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.27,-0.94);
	glVertex2f(0.27,-0.88);
	glVertex2f(0.33,-0.88);
	glVertex2f(0.33,-0.94);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.34,-0.94);
	glVertex2f(0.34,-0.88);
	glVertex2f(0.40,-0.88);
	glVertex2f(0.40,-0.94);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.41,-0.94);
	glVertex2f(0.41,-0.88);
	glVertex2f(0.47,-0.88);
	glVertex2f(0.47,-0.94);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.48,-0.94);
	glVertex2f(0.48,-0.88);
	glVertex2f(0.54,-0.88);
	glVertex2f(0.54,-0.94);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.55,-0.94);
	glVertex2f(0.55,-0.88);
	glVertex2f(0.61,-0.88);
	glVertex2f(0.61,-0.94);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.62,-0.94);
	glVertex2f(0.62,-0.88);
	glVertex2f(0.68,-0.88);
	glVertex2f(0.68,-0.94);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.69,-0.94);
	glVertex2f(0.69,-0.88);
	glVertex2f(0.75,-0.88);
	glVertex2f(0.75,-0.94);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.76,-0.94);
	glVertex2f(0.76,-0.88);
	glVertex2f(0.82,-0.88);
	glVertex2f(0.82,-0.94);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.83,-0.94);
	glVertex2f(0.83,-0.88);
	glVertex2f(0.89,-0.88);
	glVertex2f(0.89,-0.94);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(0.90,-0.94);
	glVertex2f(0.90,-0.88);
	glVertex2f(0.95,-0.88);
	glVertex2f(0.95,-0.94);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(0.96,-0.94);
	glVertex2f(0.96,-0.88);
	glVertex2f(1.0,-0.88);
	glVertex2f(1.0,-0.94);
    glEnd();



    //3rdQua
    //Column0
    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.01,-0.05);
	glVertex2f(-0.01,-0.11);
	glVertex2f(-0.06,-0.11);
	glVertex2f(-0.06,-0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.07,-0.05);
	glVertex2f(-0.07,-0.11);
	glVertex2f(-0.13,-0.11);
	glVertex2f(-0.13,-0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.14,-0.05);
	glVertex2f(-0.14,-0.11);
	glVertex2f(-0.19,-0.11);
	glVertex2f(-0.19,-0.05);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.20,-0.05);
	glVertex2f(-0.20,-0.11);
	glVertex2f(-0.26,-0.11);
	glVertex2f(-0.26,-0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.27,-0.05);
	glVertex2f(-0.27,-0.11);
	glVertex2f(-0.33,-0.11);
	glVertex2f(-0.33,-0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.34,-0.05);
	glVertex2f(-0.34,-0.11);
	glVertex2f(-0.40,-0.11);
	glVertex2f(-0.40,-0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.41,-0.05);
	glVertex2f(-0.41,-0.11);
	glVertex2f(-0.47,-0.11);
	glVertex2f(-0.47,-0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.48,-0.05);
	glVertex2f(-0.48,-0.11);
	glVertex2f(-0.54,-0.11);
	glVertex2f(-0.54,-0.05);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.55,-0.05);
	glVertex2f(-0.55,-0.11);
	glVertex2f(-0.61,-0.11);
	glVertex2f(-0.61,-0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.62,-0.05);
	glVertex2f(-0.62,-0.11);
	glVertex2f(-0.68,-0.11);
	glVertex2f(-0.68,-0.05);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.69,-0.05);
	glVertex2f(-0.69,-0.11);
	glVertex2f(-0.75,-0.11);
	glVertex2f(-0.75,-0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.76,-0.05);
	glVertex2f(-0.76,-0.11);
	glVertex2f(-0.82,-0.11);
	glVertex2f(-0.82,-0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.83,-0.05);
	glVertex2f(-0.83,-0.11);
	glVertex2f(-0.89,-0.11);
	glVertex2f(-0.89,-0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.90,-0.05);
	glVertex2f(-0.90,-0.11);
	glVertex2f(-0.95,-0.11);
	glVertex2f(-0.95,-0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.96,-0.05);
	glVertex2f(-0.96,-0.11);
	glVertex2f(-1.0,-0.11);
	glVertex2f(-1.0,-0.05);
    glEnd();



    //Column1
	glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.01,-0.12);
	glVertex2f(-0.01,-0.18);
	glVertex2f(-0.13,-0.18);
	glVertex2f(-0.13,-0.12);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.14,-0.12);
	glVertex2f(-0.14,-0.18);
	glVertex2f(-0.26,-0.18);
	glVertex2f(-0.26,-0.12);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.27,-0.12);
	glVertex2f(-0.27,-0.18);
	glVertex2f(-0.40,-0.18);
	glVertex2f(-0.40,-0.12);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.41,-0.12);
	glVertex2f(-0.41,-0.18);
	glVertex2f(-0.54,-0.18);
	glVertex2f(-0.54,-0.12);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.55,-0.12);
	glVertex2f(-0.55,-0.18);
	glVertex2f(-0.68,-0.18);
	glVertex2f(-0.68,-0.12);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.69,-0.12);
	glVertex2f(-0.69,-0.18);
	glVertex2f(-0.82,-0.18);
	glVertex2f(-0.82,-0.12);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.83,-0.12);
	glVertex2f(-0.83,-0.18);
	glVertex2f(-0.95,-0.18);
	glVertex2f(-0.95,-0.12);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.96,-0.12);
	glVertex2f(-0.96,-0.18);
	glVertex2f(-1.0,-0.18);
	glVertex2f(-1.0,-0.12);
    glEnd();




    //Column2
    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.01,-0.19);
	glVertex2f(-0.01,-0.25);
	glVertex2f(-0.06,-0.25);
	glVertex2f(-0.06,-0.19);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.07,-0.19);
	glVertex2f(-0.07,-0.25);
	glVertex2f(-0.13,-0.25);
	glVertex2f(-0.13,-0.19);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.14,-0.19);
	glVertex2f(-0.14,-0.25);
	glVertex2f(-0.19,-0.25);
	glVertex2f(-0.19,-0.19);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.20,-0.19);
	glVertex2f(-0.20,-0.25);
	glVertex2f(-0.26,-0.25);
	glVertex2f(-0.26,-0.19);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.27,-0.19);
	glVertex2f(-0.27,-0.25);
	glVertex2f(-0.33,-0.25);
	glVertex2f(-0.33,-0.19);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.34,-0.19);
	glVertex2f(-0.34,-0.25);
	glVertex2f(-0.40,-0.25);
	glVertex2f(-0.40,-0.19);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.41,-0.19);
	glVertex2f(-0.41,-0.25);
	glVertex2f(-0.47,-0.25);
	glVertex2f(-0.47,-0.19);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.48,-0.19);
	glVertex2f(-0.48,-0.25);
	glVertex2f(-0.54,-0.25);
	glVertex2f(-0.54,-0.19);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.55,-0.19);
	glVertex2f(-0.55,-0.25);
	glVertex2f(-0.61,-0.25);
	glVertex2f(-0.61,-0.19);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.62,-0.19);
	glVertex2f(-0.62,-0.25);
	glVertex2f(-0.68,-0.25);
	glVertex2f(-0.68,-0.19);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.69,-0.19);
	glVertex2f(-0.69,-0.25);
	glVertex2f(-0.75,-0.25);
	glVertex2f(-0.75,-0.19);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.76,-0.19);
	glVertex2f(-0.76,-0.25);
	glVertex2f(-0.82,-0.25);
	glVertex2f(-0.82,-0.19);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.83,-0.19);
	glVertex2f(-0.83,-0.25);
	glVertex2f(-0.89,-0.25);
	glVertex2f(-0.89,-0.19);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.90,-0.19);
	glVertex2f(-0.90,-0.25);
	glVertex2f(-0.95,-0.25);
	glVertex2f(-0.95,-0.19);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.96,-0.19);
	glVertex2f(-0.96,-0.25);
	glVertex2f(-1.0,-0.25);
	glVertex2f(-1.0,-0.19);
    glEnd();



    //Column3
	glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.01,-0.26);
	glVertex2f(-0.01,-0.31);
	glVertex2f(-0.13,-0.31);
	glVertex2f(-0.13,-0.26);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.14,-0.26);
	glVertex2f(-0.14,-0.31);
	glVertex2f(-0.26,-0.31);
	glVertex2f(-0.26,-0.26);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.27,-0.26);
	glVertex2f(-0.27,-0.31);
	glVertex2f(-0.40,-0.31);
	glVertex2f(-0.40,-0.26);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.41,-0.26);
	glVertex2f(-0.41,-0.31);
	glVertex2f(-0.54,-0.31);
	glVertex2f(-0.54,-0.26);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.55,-0.26);
	glVertex2f(-0.55,-0.31);
	glVertex2f(-0.68,-0.31);
	glVertex2f(-0.68,-0.26);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.69,-0.26);
	glVertex2f(-0.69,-0.31);
	glVertex2f(-0.82,-0.31);
	glVertex2f(-0.82,-0.26);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.83,-0.26);
	glVertex2f(-0.83,-0.31);
	glVertex2f(-0.95,-0.31);
	glVertex2f(-0.95,-0.26);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.96,-0.26);
	glVertex2f(-0.96,-0.31);
	glVertex2f(-1.0,-0.31);
	glVertex2f(-1.0,-0.26);
    glEnd();




    //Column4
    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.01,-0.32);
	glVertex2f(-0.01,-0.38);
	glVertex2f(-0.06,-0.38);
	glVertex2f(-0.06,-0.32);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.07,-0.32);
	glVertex2f(-0.07,-0.38);
	glVertex2f(-0.13,-0.38);
	glVertex2f(-0.13,-0.32);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.14,-0.32);
	glVertex2f(-0.14,-0.38);
	glVertex2f(-0.19,-0.38);
	glVertex2f(-0.19,-0.32);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.20,-0.32);
	glVertex2f(-0.20,-0.38);
	glVertex2f(-0.26,-0.38);
	glVertex2f(-0.26,-0.32);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.27,-0.32);
	glVertex2f(-0.27,-0.38);
	glVertex2f(-0.33,-0.38);
	glVertex2f(-0.33,-0.32);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.34,-0.32);
	glVertex2f(-0.34,-0.38);
	glVertex2f(-0.40,-0.38);
	glVertex2f(-0.40,-0.32);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.41,-0.32);
	glVertex2f(-0.41,-0.38);
	glVertex2f(-0.47,-0.38);
	glVertex2f(-0.47,-0.32);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.48,-0.32);
	glVertex2f(-0.48,-0.38);
	glVertex2f(-0.54,-0.38);
	glVertex2f(-0.54,-0.32);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.55,-0.32);
	glVertex2f(-0.55,-0.38);
	glVertex2f(-0.61,-0.38);
	glVertex2f(-0.61,-0.32);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.62,-0.32);
	glVertex2f(-0.62,-0.38);
	glVertex2f(-0.68,-0.38);
	glVertex2f(-0.68,-0.32);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.69,-0.32);
	glVertex2f(-0.69,-0.38);
	glVertex2f(-0.75,-0.38);
	glVertex2f(-0.75,-0.32);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.76,-0.32);
	glVertex2f(-0.76,-0.38);
	glVertex2f(-0.82,-0.38);
	glVertex2f(-0.82,-0.32);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.83,-0.32);
	glVertex2f(-0.83,-0.38);
	glVertex2f(-0.89,-0.38);
	glVertex2f(-0.89,-0.32);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.90,-0.32);
	glVertex2f(-0.90,-0.38);
	glVertex2f(-0.95,-0.38);
	glVertex2f(-0.95,-0.32);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.96,-0.32);
	glVertex2f(-0.96,-0.38);
	glVertex2f(-1.0,-0.38);
	glVertex2f(-1.0,-0.32);
    glEnd();




    //Column5
	glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.01,-0.39);
	glVertex2f(-0.01,-0.45);
	glVertex2f(-0.13,-0.45);
	glVertex2f(-0.13,-0.39);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.14,-0.39);
	glVertex2f(-0.14,-0.45);
	glVertex2f(-0.26,-0.45);
	glVertex2f(-0.26,-0.39);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.27,-0.39);
	glVertex2f(-0.27,-0.45);
	glVertex2f(-0.40,-0.45);
	glVertex2f(-0.40,-0.39);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.41,-0.39);
	glVertex2f(-0.41,-0.45);
	glVertex2f(-0.54,-0.45);
	glVertex2f(-0.54,-0.39);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.55,-0.39);
	glVertex2f(-0.55,-0.45);
	glVertex2f(-0.68,-0.45);
	glVertex2f(-0.68,-0.39);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.69,-0.39);
	glVertex2f(-0.69,-0.45);
	glVertex2f(-0.82,-0.45);
	glVertex2f(-0.82,-0.39);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.83,-0.39);
	glVertex2f(-0.83,-0.45);
	glVertex2f(-0.95,-0.45);
	glVertex2f(-0.95,-0.39);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.96,-0.39);
	glVertex2f(-0.96,-0.45);
	glVertex2f(-1.0,-0.45);
	glVertex2f(-1.0,-0.39);
    glEnd();




    //Column6
    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.01,-0.46);
	glVertex2f(-0.01,-0.52);
	glVertex2f(-0.06,-0.52);
	glVertex2f(-0.06,-0.46);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.07,-0.46);
	glVertex2f(-0.07,-0.52);
	glVertex2f(-0.13,-0.52);
	glVertex2f(-0.13,-0.46);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.14,-0.46);
	glVertex2f(-0.14,-0.52);
	glVertex2f(-0.19,-0.52);
	glVertex2f(-0.19,-0.46);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.20,-0.46);
	glVertex2f(-0.20,-0.52);
	glVertex2f(-0.26,-0.52);
	glVertex2f(-0.26,-0.46);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.27,-0.46);
	glVertex2f(-0.27,-0.52);
	glVertex2f(-0.33,-0.52);
	glVertex2f(-0.33,-0.46);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.34,-0.46);
	glVertex2f(-0.34,-0.52);
	glVertex2f(-0.40,-0.52);
	glVertex2f(-0.40,-0.46);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.41,-0.46);
	glVertex2f(-0.41,-0.52);
	glVertex2f(-0.47,-0.52);
	glVertex2f(-0.47,-0.46);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.48,-0.46);
	glVertex2f(-0.48,-0.52);
	glVertex2f(-0.54,-0.52);
	glVertex2f(-0.54,-0.46);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.55,-0.46);
	glVertex2f(-0.55,-0.52);
	glVertex2f(-0.61,-0.52);
	glVertex2f(-0.61,-0.46);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.62,-0.46);
	glVertex2f(-0.62,-0.52);
	glVertex2f(-0.68,-0.52);
	glVertex2f(-0.68,-0.46);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.69,-0.46);
	glVertex2f(-0.69,-0.52);
	glVertex2f(-0.75,-0.52);
	glVertex2f(-0.75,-0.46);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.76,-0.46);
	glVertex2f(-0.76,-0.52);
	glVertex2f(-0.82,-0.52);
	glVertex2f(-0.82,-0.46);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.83,-0.46);
	glVertex2f(-0.83,-0.52);
	glVertex2f(-0.89,-0.52);
	glVertex2f(-0.89,-0.46);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.90,-0.46);
	glVertex2f(-0.90,-0.52);
	glVertex2f(-0.95,-0.52);
	glVertex2f(-0.95,-0.46);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.96,-0.46);
	glVertex2f(-0.96,-0.52);
	glVertex2f(-1.0,-0.52);
	glVertex2f(-1.0,-0.46);
    glEnd();




    //Column7
	glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.01,-0.53);
	glVertex2f(-0.01,-0.59);
	glVertex2f(-0.13,-0.59);
	glVertex2f(-0.13,-0.53);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.14,-0.53);
	glVertex2f(-0.14,-0.59);
	glVertex2f(-0.26,-0.59);
	glVertex2f(-0.26,-0.53);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.27,-0.53);
	glVertex2f(-0.27,-0.59);
	glVertex2f(-0.40,-0.59);
	glVertex2f(-0.40,-0.53);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.41,-0.53);
	glVertex2f(-0.41,-0.59);
	glVertex2f(-0.54,-0.59);
	glVertex2f(-0.54,-0.53);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.55,-0.53);
	glVertex2f(-0.55,-0.59);
	glVertex2f(-0.68,-0.59);
	glVertex2f(-0.68,-0.53);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.69,-0.53);
	glVertex2f(-0.69,-0.59);
	glVertex2f(-0.82,-0.59);
	glVertex2f(-0.82,-0.53);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.83,-0.53);
	glVertex2f(-0.83,-0.59);
	glVertex2f(-0.95,-0.59);
	glVertex2f(-0.95,-0.53);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.96,-0.53);
	glVertex2f(-0.96,-0.59);
	glVertex2f(-1.0,-0.59);
	glVertex2f(-1.0,-0.53);
    glEnd();



    //Column8
    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.01,-0.60);
	glVertex2f(-0.01,-0.66);
	glVertex2f(-0.06,-0.66);
	glVertex2f(-0.06,-0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.07,-0.60);
	glVertex2f(-0.07,-0.66);
	glVertex2f(-0.13,-0.66);
	glVertex2f(-0.13,-0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.14,-0.60);
	glVertex2f(-0.14,-0.66);
	glVertex2f(-0.19,-0.66);
	glVertex2f(-0.19,-0.60);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.20,-0.60);
	glVertex2f(-0.20,-0.66);
	glVertex2f(-0.26,-0.66);
	glVertex2f(-0.26,-0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.27,-0.60);
	glVertex2f(-0.27,-0.66);
	glVertex2f(-0.33,-0.66);
	glVertex2f(-0.33,-0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.34,-0.60);
	glVertex2f(-0.34,-0.66);
	glVertex2f(-0.40,-0.66);
	glVertex2f(-0.40,-0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.41,-0.60);
	glVertex2f(-0.41,-0.66);
	glVertex2f(-0.47,-0.66);
	glVertex2f(-0.47,-0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.48,-0.60);
	glVertex2f(-0.48,-0.66);
	glVertex2f(-0.54,-0.66);
	glVertex2f(-0.54,-0.60);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.55,-0.60);
	glVertex2f(-0.55,-0.66);
	glVertex2f(-0.61,-0.66);
	glVertex2f(-0.61,-0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.62,-0.60);
	glVertex2f(-0.62,-0.66);
	glVertex2f(-0.68,-0.66);
	glVertex2f(-0.68,-0.60);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.69,-0.60);
	glVertex2f(-0.69,-0.66);
	glVertex2f(-0.75,-0.66);
	glVertex2f(-0.75,-0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.76,-0.60);
	glVertex2f(-0.76,-0.66);
	glVertex2f(-0.82,-0.66);
	glVertex2f(-0.82,-0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.83,-0.60);
	glVertex2f(-0.83,-0.66);
	glVertex2f(-0.89,-0.66);
	glVertex2f(-0.89,-0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.90,-0.60);
	glVertex2f(-0.90,-0.66);
	glVertex2f(-0.95,-0.66);
	glVertex2f(-0.95,-0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.96,-0.60);
	glVertex2f(-0.96,-0.66);
	glVertex2f(-1.0,-0.66);
	glVertex2f(-1.0,-0.60);
    glEnd();



    //Column9
	glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.01,-0.67);
	glVertex2f(-0.01,-0.73);
	glVertex2f(-0.13,-0.73);
	glVertex2f(-0.13,-0.67);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.14,-0.67);
	glVertex2f(-0.14,-0.73);
	glVertex2f(-0.26,-0.73);
	glVertex2f(-0.26,-0.67);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.27,-0.67);
	glVertex2f(-0.27,-0.73);
	glVertex2f(-0.40,-0.73);
	glVertex2f(-0.40,-0.67);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.41,-0.67);
	glVertex2f(-0.41,-0.73);
	glVertex2f(-0.54,-0.73);
	glVertex2f(-0.54,-0.67);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.55,-0.67);
	glVertex2f(-0.55,-0.73);
	glVertex2f(-0.68,-0.73);
	glVertex2f(-0.68,-0.67);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.69,-0.67);
	glVertex2f(-0.69,-0.73);
	glVertex2f(-0.82,-0.73);
	glVertex2f(-0.82,-0.67);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.83,-0.67);
	glVertex2f(-0.83,-0.73);
	glVertex2f(-0.95,-0.73);
	glVertex2f(-0.95,-0.67);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.96,-0.67);
	glVertex2f(-0.96,-0.73);
	glVertex2f(-1.0,-0.73);
	glVertex2f(-1.0,-0.67);
    glEnd();


    //Column10
    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.01,-0.74);
	glVertex2f(-0.01,-0.80);
	glVertex2f(-0.06,-0.80);
	glVertex2f(-0.06,-0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.07,-0.74);
	glVertex2f(-0.07,-0.80);
	glVertex2f(-0.13,-0.80);
	glVertex2f(-0.13,-0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.14,-0.74);
	glVertex2f(-0.14,-0.80);
	glVertex2f(-0.19,-0.80);
	glVertex2f(-0.19,-0.74);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.20,-0.74);
	glVertex2f(-0.20,-0.80);
	glVertex2f(-0.26,-0.80);
	glVertex2f(-0.26,-0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.27,-0.74);
	glVertex2f(-0.27,-0.80);
	glVertex2f(-0.33,-0.80);
	glVertex2f(-0.33,-0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.34,-0.74);
	glVertex2f(-0.34,-0.80);
	glVertex2f(-0.40,-0.80);
	glVertex2f(-0.40,-0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.41,-0.74);
	glVertex2f(-0.41,-0.80);
	glVertex2f(-0.47,-0.80);
	glVertex2f(-0.47,-0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.48,-0.74);
	glVertex2f(-0.48,-0.80);
	glVertex2f(-0.54,-0.80);
	glVertex2f(-0.54,-0.74);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.55,-0.74);
	glVertex2f(-0.55,-0.80);
	glVertex2f(-0.61,-0.80);
	glVertex2f(-0.61,-0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.62,-0.74);
	glVertex2f(-0.62,-0.80);
	glVertex2f(-0.68,-0.80);
	glVertex2f(-0.68,-0.74);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.69,-0.74);
	glVertex2f(-0.69,-0.80);
	glVertex2f(-0.75,-0.80);
	glVertex2f(-0.75,-0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.76,-0.74);
	glVertex2f(-0.76,-0.80);
	glVertex2f(-0.82,-0.80);
	glVertex2f(-0.82,-0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.83,-0.74);
	glVertex2f(-0.83,-0.80);
	glVertex2f(-0.89,-0.80);
	glVertex2f(-0.89,-0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.90,-0.74);
	glVertex2f(-0.90,-0.80);
	glVertex2f(-0.95,-0.80);
	glVertex2f(-0.95,-0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.96,-0.74);
	glVertex2f(-0.96,-0.80);
	glVertex2f(-1.0,-0.80);
	glVertex2f(-1.0,-0.74);
    glEnd();



    //Colum11
	glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.01,-0.81);
	glVertex2f(-0.01,-0.87);
	glVertex2f(-0.13,-0.87);
	glVertex2f(-0.13,-0.81);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.14,-0.81);
	glVertex2f(-0.14,-0.87);
	glVertex2f(-0.26,-0.87);
	glVertex2f(-0.26,-0.81);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.27,-0.81);
	glVertex2f(-0.27,-0.87);
	glVertex2f(-0.40,-0.87);
	glVertex2f(-0.40,-0.81);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.41,-0.81);
	glVertex2f(-0.41,-0.87);
	glVertex2f(-0.54,-0.87);
	glVertex2f(-0.54,-0.81);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.55,-0.81);
	glVertex2f(-0.55,-0.87);
	glVertex2f(-0.68,-0.87);
	glVertex2f(-0.68,-0.81);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.69,-0.81);
	glVertex2f(-0.69,-0.87);
	glVertex2f(-0.82,-0.87);
	glVertex2f(-0.82,-0.81);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.83,-0.81);
	glVertex2f(-0.83,-0.87);
	glVertex2f(-0.95,-0.87);
	glVertex2f(-0.95,-0.81);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.96,-0.81);
	glVertex2f(-0.96,-0.87);
	glVertex2f(-1.0,-0.87);
	glVertex2f(-1.0,-0.81);
    glEnd();




    //Column12
    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.01,-0.88);
	glVertex2f(-0.01,-0.94);
	glVertex2f(-0.06,-0.94);
	glVertex2f(-0.06,-0.88);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.07,-0.88);
	glVertex2f(-0.07,-0.94);
	glVertex2f(-0.13,-0.94);
	glVertex2f(-0.13,-0.88);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.14,-0.88);
	glVertex2f(-0.14,-0.94);
	glVertex2f(-0.19,-0.94);
	glVertex2f(-0.19,-0.88);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.20,-0.88);
	glVertex2f(-0.20,-0.94);
	glVertex2f(-0.26,-0.94);
	glVertex2f(-0.26,-0.88);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.27,-0.94);
	glVertex2f(-0.27,-0.88);
	glVertex2f(-0.33,-0.88);
	glVertex2f(-0.33,-0.94);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.34,-0.94);
	glVertex2f(-0.34,-0.88);
	glVertex2f(-0.40,-0.88);
	glVertex2f(-0.40,-0.94);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.41,-0.94);
	glVertex2f(-0.41,-0.88);
	glVertex2f(-0.47,-0.88);
	glVertex2f(-0.47,-0.94);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.48,-0.94);
	glVertex2f(-0.48,-0.88);
	glVertex2f(-0.54,-0.88);
	glVertex2f(-0.54,-0.94);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.55,-0.94);
	glVertex2f(-0.55,-0.88);
	glVertex2f(-0.61,-0.88);
	glVertex2f(-0.61,-0.94);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.62,-0.94);
	glVertex2f(-0.62,-0.88);
	glVertex2f(-0.68,-0.88);
	glVertex2f(-0.68,-0.94);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.69,-0.94);
	glVertex2f(-0.69,-0.88);
	glVertex2f(-0.75,-0.88);
	glVertex2f(-0.75,-0.94);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.76,-0.94);
	glVertex2f(-0.76,-0.88);
	glVertex2f(-0.82,-0.88);
	glVertex2f(-0.82,-0.94);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.83,-0.94);
	glVertex2f(-0.83,-0.88);
	glVertex2f(-0.89,-0.88);
	glVertex2f(-0.89,-0.94);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.90,-0.94);
	glVertex2f(-0.90,-0.88);
	glVertex2f(-0.95,-0.88);
	glVertex2f(-0.95,-0.94);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.96,-0.94);
	glVertex2f(-0.96,-0.88);
	glVertex2f(-1.0,-0.88);
	glVertex2f(-1.0,-0.94);
    glEnd();



    //4thQua
    //Column0
    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.01,0.05);
	glVertex2f(-0.01,0.11);
	glVertex2f(-0.06,0.11);
	glVertex2f(-0.06,0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.07,0.05);
	glVertex2f(-0.07,0.11);
	glVertex2f(-0.13,0.11);
	glVertex2f(-0.13,0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.14,0.05);
	glVertex2f(-0.14,0.11);
	glVertex2f(-0.19,0.11);
	glVertex2f(-0.19,0.05);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.20,0.05);
	glVertex2f(-0.20,0.11);
	glVertex2f(-0.26,0.11);
	glVertex2f(-0.26,0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.27,0.05);
	glVertex2f(-0.27,0.11);
	glVertex2f(-0.33,0.11);
	glVertex2f(-0.33,0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.34,0.05);
	glVertex2f(-0.34,0.11);
	glVertex2f(-0.40,0.11);
	glVertex2f(-0.40,0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.41,0.05);
	glVertex2f(-0.41,0.11);
	glVertex2f(-0.47,0.11);
	glVertex2f(-0.47,0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.48,0.05);
	glVertex2f(-0.48,0.11);
	glVertex2f(-0.54,0.11);
	glVertex2f(-0.54,0.05);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.55,0.05);
	glVertex2f(-0.55,0.11);
	glVertex2f(-0.61,0.11);
	glVertex2f(-0.61,0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.62,0.05);
	glVertex2f(-0.62,0.11);
	glVertex2f(-0.68,0.11);
	glVertex2f(-0.68,0.05);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.69,0.05);
	glVertex2f(-0.69,0.11);
	glVertex2f(-0.75,0.11);
	glVertex2f(-0.75,0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.76,0.05);
	glVertex2f(-0.76,0.11);
	glVertex2f(-0.82,0.11);
	glVertex2f(-0.82,0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.83,0.05);
	glVertex2f(-0.83,0.11);
	glVertex2f(-0.89,0.11);
	glVertex2f(-0.89,0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.90,0.05);
	glVertex2f(-0.90,0.11);
	glVertex2f(-0.95,0.11);
	glVertex2f(-0.95,0.05);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.96,0.05);
	glVertex2f(-0.96,0.11);
	glVertex2f(-1.0,0.11);
	glVertex2f(-1.0,0.05);
    glEnd();



    //Column1
	glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.01,0.12);
	glVertex2f(-0.01,0.18);
	glVertex2f(-0.13,0.18);
	glVertex2f(-0.13,0.12);
    glEnd();

    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.14,0.12);
	glVertex2f(-0.14,0.18);
	glVertex2f(-0.26,0.18);
	glVertex2f(-0.26,0.12);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.27,0.12);
	glVertex2f(-0.27,0.18);
	glVertex2f(-0.40,0.18);
	glVertex2f(-0.40,0.12);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.41,0.12);
	glVertex2f(-0.41,0.18);
	glVertex2f(-0.54,0.18);
	glVertex2f(-0.54,0.12);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.55,0.12);
	glVertex2f(-0.55,0.18);
	glVertex2f(-0.68,0.18);
	glVertex2f(-0.68,0.12);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.69,0.12);
	glVertex2f(-0.69,0.18);
	glVertex2f(-0.82,0.18);
	glVertex2f(-0.82,0.12);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.83,0.12);
	glVertex2f(-0.83,0.18);
	glVertex2f(-0.95,0.18);
	glVertex2f(-0.95,0.12);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.96,0.12);
	glVertex2f(-0.96,0.18);
	glVertex2f(-1.0,0.18);
	glVertex2f(-1.0,0.12);
    glEnd();




    //Column2
    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.01,0.19);
	glVertex2f(-0.01,0.25);
	glVertex2f(-0.06,0.25);
	glVertex2f(-0.06,0.19);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.07,0.19);
	glVertex2f(-0.07,0.25);
	glVertex2f(-0.13,0.25);
	glVertex2f(-0.13,0.19);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.14,0.19);
	glVertex2f(-0.14,0.25);
	glVertex2f(-0.19,0.25);
	glVertex2f(-0.19,0.19);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.20,0.19);
	glVertex2f(-0.20,0.25);
	glVertex2f(-0.26,0.25);
	glVertex2f(-0.26,0.19);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.27,0.19);
	glVertex2f(-0.27,0.25);
	glVertex2f(-0.33,0.25);
	glVertex2f(-0.33,0.19);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.34,0.19);
	glVertex2f(-0.34,0.25);
	glVertex2f(-0.40,0.25);
	glVertex2f(-0.40,0.19);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.41,0.19);
	glVertex2f(-0.41,0.25);
	glVertex2f(-0.47,0.25);
	glVertex2f(-0.47,0.19);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.48,0.19);
	glVertex2f(-0.48,0.25);
	glVertex2f(-0.54,0.25);
	glVertex2f(-0.54,0.19);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.55,0.19);
	glVertex2f(-0.55,0.25);
	glVertex2f(-0.61,0.25);
	glVertex2f(-0.61,0.19);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.62,0.19);
	glVertex2f(-0.62,0.25);
	glVertex2f(-0.68,0.25);
	glVertex2f(-0.68,0.19);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.69,0.19);
	glVertex2f(-0.69,0.25);
	glVertex2f(-0.75,0.25);
	glVertex2f(-0.75,0.19);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.76,0.19);
	glVertex2f(-0.76,0.25);
	glVertex2f(-0.82,0.25);
	glVertex2f(-0.82,0.19);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.83,0.19);
	glVertex2f(-0.83,0.25);
	glVertex2f(-0.89,0.25);
	glVertex2f(-0.89,0.19);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.90,0.19);
	glVertex2f(-0.90,0.25);
	glVertex2f(-0.95,0.25);
	glVertex2f(-0.95,0.19);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.96,0.19);
	glVertex2f(-0.96,0.25);
	glVertex2f(-1.0,0.25);
	glVertex2f(-1.0,0.19);
    glEnd();



    //Column3
	glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.01,0.26);
	glVertex2f(-0.01,0.31);
	glVertex2f(-0.13,0.31);
	glVertex2f(-0.13,0.26);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.14,0.26);
	glVertex2f(-0.14,0.31);
	glVertex2f(-0.26,0.31);
	glVertex2f(-0.26,0.26);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.27,0.26);
	glVertex2f(-0.27,0.31);
	glVertex2f(-0.40,0.31);
	glVertex2f(-0.40,0.26);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.41,0.26);
	glVertex2f(-0.41,0.31);
	glVertex2f(-0.54,0.31);
	glVertex2f(-0.54,0.26);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.55,0.26);
	glVertex2f(-0.55,0.31);
	glVertex2f(-0.68,0.31);
	glVertex2f(-0.68,0.26);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.69,0.26);
	glVertex2f(-0.69,0.31);
	glVertex2f(-0.82,0.31);
	glVertex2f(-0.82,0.26);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.83,0.26);
	glVertex2f(-0.83,0.31);
	glVertex2f(-0.95,0.31);
	glVertex2f(-0.95,0.26);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.96,0.26);
	glVertex2f(-0.96,0.31);
	glVertex2f(-1.0,0.31);
	glVertex2f(-1.0,0.26);
    glEnd();




    //Column4
    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.01,0.32);
	glVertex2f(-0.01,0.38);
	glVertex2f(-0.06,0.38);
	glVertex2f(-0.06,0.32);
    glEnd();

    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.07,0.32);
	glVertex2f(-0.07,0.38);
	glVertex2f(-0.13,0.38);
	glVertex2f(-0.13,0.32);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.14,0.32);
	glVertex2f(-0.14,0.38);
	glVertex2f(-0.19,0.38);
	glVertex2f(-0.19,0.32);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.20,0.32);
	glVertex2f(-0.20,0.38);
	glVertex2f(-0.26,0.38);
	glVertex2f(-0.26,0.32);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.27,0.32);
	glVertex2f(-0.27,0.38);
	glVertex2f(-0.33,0.38);
	glVertex2f(-0.33,0.32);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.34,0.32);
	glVertex2f(-0.34,0.38);
	glVertex2f(-0.40,0.38);
	glVertex2f(-0.40,0.32);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.41,0.32);
	glVertex2f(-0.41,0.38);
	glVertex2f(-0.47,0.38);
	glVertex2f(-0.47,0.32);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.48,0.32);
	glVertex2f(-0.48,0.38);
	glVertex2f(-0.54,0.38);
	glVertex2f(-0.54,0.32);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.55,0.32);
	glVertex2f(-0.55,0.38);
	glVertex2f(-0.61,0.38);
	glVertex2f(-0.61,0.32);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.62,0.32);
	glVertex2f(-0.62,0.38);
	glVertex2f(-0.68,0.38);
	glVertex2f(-0.68,0.32);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.69,0.32);
	glVertex2f(-0.69,0.38);
	glVertex2f(-0.75,0.38);
	glVertex2f(-0.75,0.32);
    glEnd();

    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.76,0.32);
	glVertex2f(-0.76,0.38);
	glVertex2f(-0.82,0.38);
	glVertex2f(-0.82,0.32);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.83,0.32);
	glVertex2f(-0.83,0.38);
	glVertex2f(-0.89,0.38);
	glVertex2f(-0.89,0.32);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.90,0.32);
	glVertex2f(-0.90,0.38);
	glVertex2f(-0.95,0.38);
	glVertex2f(-0.95,0.32);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.96,0.32);
	glVertex2f(-0.96,0.38);
	glVertex2f(-1.0,0.38);
	glVertex2f(-1.0,0.32);
    glEnd();




    //Column5
	glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.01,0.39);
	glVertex2f(-0.01,0.45);
	glVertex2f(-0.13,0.45);
	glVertex2f(-0.13,0.39);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.14,0.39);
	glVertex2f(-0.14,0.45);
	glVertex2f(-0.26,0.45);
	glVertex2f(-0.26,0.39);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.27,0.39);
	glVertex2f(-0.27,0.45);
	glVertex2f(-0.40,0.45);
	glVertex2f(-0.40,0.39);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.41,0.39);
	glVertex2f(-0.41,0.45);
	glVertex2f(-0.54,0.45);
	glVertex2f(-0.54,0.39);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.55,0.39);
	glVertex2f(-0.55,0.45);
	glVertex2f(-0.68,0.45);
	glVertex2f(-0.68,0.39);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.69,0.39);
	glVertex2f(-0.69,0.45);
	glVertex2f(-0.82,0.45);
	glVertex2f(-0.82,0.39);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.83,0.39);
	glVertex2f(-0.83,0.45);
	glVertex2f(-0.95,0.45);
	glVertex2f(-0.95,0.39);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.96,0.39);
	glVertex2f(-0.96,0.45);
	glVertex2f(-1.0,0.45);
	glVertex2f(-1.0,0.39);
    glEnd();




    //Column6
    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.01,0.46);
	glVertex2f(-0.01,0.52);
	glVertex2f(-0.06,0.52);
	glVertex2f(-0.06,0.46);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.07,0.46);
	glVertex2f(-0.07,0.52);
	glVertex2f(-0.13,0.52);
	glVertex2f(-0.13,0.46);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.14,0.46);
	glVertex2f(-0.14,0.52);
	glVertex2f(-0.19,0.52);
	glVertex2f(-0.19,0.46);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.20,0.46);
	glVertex2f(-0.20,0.52);
	glVertex2f(-0.26,0.52);
	glVertex2f(-0.26,0.46);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.27,0.46);
	glVertex2f(-0.27,0.52);
	glVertex2f(-0.33,0.52);
	glVertex2f(-0.33,0.46);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.34,0.46);
	glVertex2f(-0.34,0.52);
	glVertex2f(-0.40,0.52);
	glVertex2f(-0.40,0.46);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.41,0.46);
	glVertex2f(-0.41,0.52);
	glVertex2f(-0.47,0.52);
	glVertex2f(-0.47,0.46);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.48,0.46);
	glVertex2f(-0.48,0.52);
	glVertex2f(-0.54,0.52);
	glVertex2f(-0.54,0.46);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.55,0.46);
	glVertex2f(-0.55,0.52);
	glVertex2f(-0.61,0.52);
	glVertex2f(-0.61,0.46);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.62,0.46);
	glVertex2f(-0.62,0.52);
	glVertex2f(-0.68,0.52);
	glVertex2f(-0.68,0.46);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.69,0.46);
	glVertex2f(-0.69,0.52);
	glVertex2f(-0.75,0.52);
	glVertex2f(-0.75,0.46);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.76,0.46);
	glVertex2f(-0.76,0.52);
	glVertex2f(-0.82,0.52);
	glVertex2f(-0.82,0.46);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.83,0.46);
	glVertex2f(-0.83,0.52);
	glVertex2f(-0.89,0.52);
	glVertex2f(-0.89,0.46);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.90,0.46);
	glVertex2f(-0.90,0.52);
	glVertex2f(-0.95,0.52);
	glVertex2f(-0.95,0.46);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.96,0.46);
	glVertex2f(-0.96,0.52);
	glVertex2f(-1.0,0.52);
	glVertex2f(-1.0,0.46);
    glEnd();




    //Column7
	glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.01,0.53);
	glVertex2f(-0.01,0.59);
	glVertex2f(-0.13,0.59);
	glVertex2f(-0.13,0.53);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.14,0.53);
	glVertex2f(-0.14,0.59);
	glVertex2f(-0.26,0.59);
	glVertex2f(-0.26,0.53);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.27,0.53);
	glVertex2f(-0.27,0.59);
	glVertex2f(-0.40,0.59);
	glVertex2f(-0.40,0.53);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.41,0.53);
	glVertex2f(-0.41,0.59);
	glVertex2f(-0.54,0.59);
	glVertex2f(-0.54,0.53);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.55,0.53);
	glVertex2f(-0.55,0.59);
	glVertex2f(-0.68,0.59);
	glVertex2f(-0.68,0.53);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.69,0.53);
	glVertex2f(-0.69,0.59);
	glVertex2f(-0.82,0.59);
	glVertex2f(-0.82,0.53);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.83,0.53);
	glVertex2f(-0.83,0.59);
	glVertex2f(-0.95,0.59);
	glVertex2f(-0.95,0.53);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.96,0.53);
	glVertex2f(-0.96,0.59);
	glVertex2f(-1.0,0.59);
	glVertex2f(-1.0,0.53);
    glEnd();



    //Column8
    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.01,0.60);
	glVertex2f(-0.01,0.66);
	glVertex2f(-0.06,0.66);
	glVertex2f(-0.06,0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.07,0.60);
	glVertex2f(-0.07,0.66);
	glVertex2f(-0.13,0.66);
	glVertex2f(-0.13,0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.14,0.60);
	glVertex2f(-0.14,0.66);
	glVertex2f(-0.19,0.66);
	glVertex2f(-0.19,0.60);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.20,0.60);
	glVertex2f(-0.20,0.66);
	glVertex2f(-0.26,0.66);
	glVertex2f(-0.26,0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.27,0.60);
	glVertex2f(-0.27,0.66);
	glVertex2f(-0.33,0.66);
	glVertex2f(-0.33,0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.34,0.60);
	glVertex2f(-0.34,0.66);
	glVertex2f(-0.40,0.66);
	glVertex2f(-0.40,0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.41,0.60);
	glVertex2f(-0.41,0.66);
	glVertex2f(-0.47,0.66);
	glVertex2f(-0.47,0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.48,0.60);
	glVertex2f(-0.48,0.66);
	glVertex2f(-0.54,0.66);
	glVertex2f(-0.54,0.60);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.55,0.60);
	glVertex2f(-0.55,0.66);
	glVertex2f(-0.61,0.66);
	glVertex2f(-0.61,0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.62,0.60);
	glVertex2f(-0.62,0.66);
	glVertex2f(-0.68,0.66);
	glVertex2f(-0.68,0.60);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.69,0.60);
	glVertex2f(-0.69,0.66);
	glVertex2f(-0.75,0.66);
	glVertex2f(-0.75,0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.76,0.60);
	glVertex2f(-0.76,0.66);
	glVertex2f(-0.82,0.66);
	glVertex2f(-0.82,0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.83,0.60);
	glVertex2f(-0.83,0.66);
	glVertex2f(-0.89,0.66);
	glVertex2f(-0.89,0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.90,0.60);
	glVertex2f(-0.90,0.66);
	glVertex2f(-0.95,0.66);
	glVertex2f(-0.95,0.60);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.96,0.60);
	glVertex2f(-0.96,0.66);
	glVertex2f(-1.0,0.66);
	glVertex2f(-1.0,0.60);
    glEnd();



    //Column9
	glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.01,0.67);
	glVertex2f(-0.01,0.73);
	glVertex2f(-0.13,0.73);
	glVertex2f(-0.13,0.67);
    glEnd();

    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.14,0.67);
	glVertex2f(-0.14,0.73);
	glVertex2f(-0.26,0.73);
	glVertex2f(-0.26,0.67);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.27,0.67);
	glVertex2f(-0.27,0.73);
	glVertex2f(-0.40,0.73);
	glVertex2f(-0.40,0.67);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.41,0.67);
	glVertex2f(-0.41,0.73);
	glVertex2f(-0.54,0.73);
	glVertex2f(-0.54,0.67);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.55,0.67);
	glVertex2f(-0.55,0.73);
	glVertex2f(-0.68,0.73);
	glVertex2f(-0.68,0.67);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.69,0.67);
	glVertex2f(-0.69,0.73);
	glVertex2f(-0.82,0.73);
	glVertex2f(-0.82,0.67);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.83,0.67);
	glVertex2f(-0.83,0.73);
	glVertex2f(-0.95,0.73);
	glVertex2f(-0.95,0.67);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.96,0.67);
	glVertex2f(-0.96,0.73);
	glVertex2f(-1.0,0.73);
	glVertex2f(-1.0,0.67);
    glEnd();


    //Column10
    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.01,0.74);
	glVertex2f(-0.01,0.80);
	glVertex2f(-0.06,0.80);
	glVertex2f(-0.06,0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.07,0.74);
	glVertex2f(-0.07,0.80);
	glVertex2f(-0.13,0.80);
	glVertex2f(-0.13,0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.14,0.74);
	glVertex2f(-0.14,0.80);
	glVertex2f(-0.19,0.80);
	glVertex2f(-0.19,0.74);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.20,0.74);
	glVertex2f(-0.20,0.80);
	glVertex2f(-0.26,0.80);
	glVertex2f(-0.26,0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.27,0.74);
	glVertex2f(-0.27,0.80);
	glVertex2f(-0.33,0.80);
	glVertex2f(-0.33,0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.34,0.74);
	glVertex2f(-0.34,0.80);
	glVertex2f(-0.40,0.80);
	glVertex2f(-0.40,0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.41,0.74);
	glVertex2f(-0.41,0.80);
	glVertex2f(-0.47,0.80);
	glVertex2f(-0.47,0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.48,0.74);
	glVertex2f(-0.48,0.80);
	glVertex2f(-0.54,0.80);
	glVertex2f(-0.54,0.74);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.55,0.74);
	glVertex2f(-0.55,0.80);
	glVertex2f(-0.61,0.80);
	glVertex2f(-0.61,0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.62,0.74);
	glVertex2f(-0.62,0.80);
	glVertex2f(-0.68,0.80);
	glVertex2f(-0.68,0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.69,0.74);
	glVertex2f(-0.69,0.80);
	glVertex2f(-0.75,0.80);
	glVertex2f(-0.75,0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.76,0.74);
	glVertex2f(-0.76,0.80);
	glVertex2f(-0.82,0.80);
	glVertex2f(-0.82,0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.83,0.74);
	glVertex2f(-0.83,0.80);
	glVertex2f(-0.89,0.80);
	glVertex2f(-0.89,0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.90,0.74);
	glVertex2f(-0.90,0.80);
	glVertex2f(-0.95,0.80);
	glVertex2f(-0.95,0.74);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.96,0.74);
	glVertex2f(-0.96,0.80);
	glVertex2f(-1.0,0.80);
	glVertex2f(-1.0,0.74);
    glEnd();



    //Colum11
	glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.01,0.81);
	glVertex2f(-0.01,0.87);
	glVertex2f(-0.13,0.87);
	glVertex2f(-0.13,0.81);
    glEnd();

    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.14,0.81);
	glVertex2f(-0.14,0.87);
	glVertex2f(-0.26,0.87);
	glVertex2f(-0.26,0.81);
    glEnd();

    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.27,0.81);
	glVertex2f(-0.27,0.87);
	glVertex2f(-0.40,0.87);
	glVertex2f(-0.40,0.81);
    glEnd();

    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.41,0.81);
	glVertex2f(-0.41,0.87);
	glVertex2f(-0.54,0.87);
	glVertex2f(-0.54,0.81);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.55,0.81);
	glVertex2f(-0.55,0.87);
	glVertex2f(-0.68,0.87);
	glVertex2f(-0.68,0.81);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.69,0.81);
	glVertex2f(-0.69,0.87);
	glVertex2f(-0.82,0.87);
	glVertex2f(-0.82,0.81);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(195,185,185);
	glVertex2f(-0.83,0.81);
	glVertex2f(-0.83,0.87);
	glVertex2f(-0.95,0.87);
	glVertex2f(-0.95,0.81);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(180,168,168);
	glVertex2f(-0.96,0.81);
	glVertex2f(-0.96,0.87);
	glVertex2f(-1.0,0.87);
	glVertex2f(-1.0,0.81);
    glEnd();




    //Column12
    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.01,0.88);
	glVertex2f(-0.01,0.94);
	glVertex2f(-0.06,0.94);
	glVertex2f(-0.06,0.88);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.07,0.88);
	glVertex2f(-0.07,0.94);
	glVertex2f(-0.13,0.94);
	glVertex2f(-0.13,0.88);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.14,0.88);
	glVertex2f(-0.14,0.94);
	glVertex2f(-0.19,0.94);
	glVertex2f(-0.19,0.88);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.20,0.88);
	glVertex2f(-0.20,0.94);
	glVertex2f(-0.26,0.94);
	glVertex2f(-0.26,0.88);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.27,0.94);
	glVertex2f(-0.27,0.88);
	glVertex2f(-0.33,0.88);
	glVertex2f(-0.33,0.94);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.34,0.94);
	glVertex2f(-0.34,0.88);
	glVertex2f(-0.40,0.88);
	glVertex2f(-0.40,0.94);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.41,0.94);
	glVertex2f(-0.41,0.88);
	glVertex2f(-0.47,0.88);
	glVertex2f(-0.47,0.94);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.48,0.94);
	glVertex2f(-0.48,0.88);
	glVertex2f(-0.54,0.88);
	glVertex2f(-0.54,0.94);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.55,0.94);
	glVertex2f(-0.55,0.88);
	glVertex2f(-0.61,0.88);
	glVertex2f(-0.61,0.94);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.62,0.94);
	glVertex2f(-0.62,0.88);
	glVertex2f(-0.68,0.88);
	glVertex2f(-0.68,0.94);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.69,0.94);
	glVertex2f(-0.69,0.88);
	glVertex2f(-0.75,0.88);
	glVertex2f(-0.75,0.94);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.76,0.94);
	glVertex2f(-0.76,0.88);
	glVertex2f(-0.82,0.88);
	glVertex2f(-0.82,0.94);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.83,0.94);
	glVertex2f(-0.83,0.88);
	glVertex2f(-0.89,0.88);
	glVertex2f(-0.89,0.94);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(169,157,157);
	glVertex2f(-0.90,0.94);
	glVertex2f(-0.90,0.88);
	glVertex2f(-0.95,0.88);
	glVertex2f(-0.95,0.94);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(159,147,147);
	glVertex2f(-0.96,0.94);
	glVertex2f(-0.96,0.88);
	glVertex2f(-1.0,0.88);
	glVertex2f(-1.0,0.94);
    glEnd();



  //Obstacles
    glBegin(GL_QUADS);
	glColor3ub(85,85,85);
	glVertex2f(-0.87,0.53);
	glVertex2f(-0.845,0.48);
	glVertex2f(-0.845,0.46);
	glVertex2f(-0.87,0.42);

	glVertex2f(-0.845,0.48);
	glVertex2f(-0.835,0.48);
	glVertex2f(-0.835,0.46);
	glVertex2f(-0.845,0.46);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(85,85,85);
	glVertex2f(-0.77,-0.0);
	glVertex2f(-0.745,-0.05);
	glVertex2f(-0.745,-0.07);
	glVertex2f(-0.77,-0.12);

	glVertex2f(-0.745,-0.05);
	glVertex2f(-0.735,-0.05);
	glVertex2f(-0.735,-0.07);
	glVertex2f(-0.745,-0.07);
    glEnd();



    //Thorn
    glBegin(GL_QUADS);
	glColor3ub(85,85,85);
	glVertex2f(-0.73,-0.59);
	glVertex2f(-0.73,-0.53);
	glVertex2f(-0.70,-0.53);
	glVertex2f(-0.70,-0.59);

	glVertex2f(-0.66,-0.59);
	glVertex2f(-0.66,-0.53);
	glVertex2f(-0.69,-0.53);
	glVertex2f(-0.69,-0.59);
    glEnd();


    //Thorn1
    glBegin(GL_TRIANGLES);
	glColor3ub(85,85,85);
	glVertex2f(-0.73,-0.53);
	glVertex2f(-0.715,-0.48);
	glVertex2f(-0.70,-0.53);

	glVertex2f(-0.66,-0.53);
	glVertex2f(-0.675,-0.48);
	glVertex2f(-0.69,-0.53);
    glEnd();


    //Thorn2
    glBegin(GL_TRIANGLES);
	glColor3ub(85,85,85);
	glVertex2f(0.08,-0.59);
	glVertex2f(0.095,-0.50);
	glVertex2f(0.11,-0.59);

	glVertex2f(0.12,-0.59);
	glVertex2f(0.135,-0.50);
	glVertex2f(0.15,-0.59);


	glVertex2f(0.65,-0.59);
	glVertex2f(0.665,-0.50);
	glVertex2f(0.68,-0.59);

	glVertex2f(0.69,-0.59);
	glVertex2f(0.705,-0.50);
	glVertex2f(0.72,-0.59);
    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(85,85,85);
	glVertex2f(-0.365,0.18);
	glVertex2f(-0.32,0.155);
	glVertex2f(-0.30,0.155);
	glVertex2f(-0.255,0.18);

	glVertex2f(-0.32,0.155);
	glVertex2f(-0.32,0.145);
	glVertex2f(-0.30,0.145);
	glVertex2f(-0.30,0.155);


	glEnd();

	glBegin(GL_QUADS);
	glColor3ub(85,85,85);
	glVertex2f(0.22,-0.24);
	glVertex2f(0.25,-0.24);
	glVertex2f(0.25,-0.27);
	glVertex2f(0.22,-0.27);


	glVertex2f(0.52,-0.24);
	glVertex2f(0.55,-0.24);
	glVertex2f(0.55,-0.27);
	glVertex2f(0.52,-0.27);
    glEnd();


    glBegin(GL_TRIANGLES);
	glColor3ub(85,85,85);
	glVertex2f(0.25,-0.27);
	glVertex2f(0.235,-0.32);
	glVertex2f(0.22,-0.27);

	glVertex2f(0.55,-0.27);
	glVertex2f(0.535,-0.32);
	glVertex2f(0.52,-0.27);
    glEnd();






    glBegin(GL_QUADS);
	glColor3ub(85,85,85);
	glVertex2f(0.35,-0.59);
	glVertex2f(0.39,-0.565);
	glVertex2f(0.41,-0.565);
	glVertex2f(0.45,-0.59);

	glVertex2f(0.39,-0.565);
	glVertex2f(0.41,-0.565);
	glVertex2f(0.41,-0.555);
	glVertex2f(0.39,-0.555);

    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(85,85,85);
	glVertex2f(0.97,-0.06);
	glVertex2f(0.945,-0.11);
	glVertex2f(0.945,-0.13);
	glVertex2f(0.97,-0.18);

	glVertex2f(0.945,-0.11);
	glVertex2f(0.945,-0.13);
	glVertex2f(0.935,-0.13);
	glVertex2f(0.935,-0.11);
    glEnd();


    glBegin(GL_TRIANGLES);
	glColor3ub(85,85,85);
	glVertex2f(0.83,0.16);
	glVertex2f(0.75,0.185);
	glVertex2f(0.83,0.20);

	glVertex2f(0.63,0.41);
	glVertex2f(0.71,0.435);
	glVertex2f(0.63,0.45);
    glEnd();


    glBegin(GL_QUADS);
	glColor3ub(85,85,85);
	glVertex2f(0.46,0.88);
	glVertex2f(0.51,0.855);
	glVertex2f(0.53,0.855);
	glVertex2f(0.58,0.88);


	glVertex2f(0.51,0.855);
	glVertex2f(0.53,0.855);
	glVertex2f(0.53,0.845);
	glVertex2f(0.51,0.845);

    glEnd();



    glBegin(GL_QUADS);
	glColor3ub(85,85,85);
	glVertex2f(-0.20,0.21);
	glVertex2f(-0.175,0.26);
	glVertex2f(-0.175,0.28);
	glVertex2f(-0.20,0.33);


	glVertex2f(-0.175,0.26);
	glVertex2f(-0.175,0.28);
	glVertex2f(-0.165,0.28);
	glVertex2f(-0.165,0.26);

    glEnd();


    // Lava
    glBegin(GL_QUADS);
    glColor3ub(254, 0, 0);
    glVertex2f(-0.40, -0.94);
    glVertex2f(-0.23, -0.94);
    glColor3ub(254, 165, 0);
    glVertex2f(-0.23, -0.88);
    glVertex2f(-0.40, -0.88);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(254, 165, 0);
    glVertex2f(-0.40, -0.88);
    glVertex2f(-0.23, -0.88);
    glColor3ub(254, 215, 0);
    glVertex2f(-0.23, -0.82);
    glVertex2f(-0.40, -0.82);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(254, 215, 0);
    glVertex2f(-0.40, -0.82);
    glVertex2f(-0.23, -0.82);
    glColor3ub(254, 99, 71);
    glVertex2f(-0.23, -0.74);
    glVertex2f(-0.40, -0.74);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(254, 99, 71);
    glVertex2f(-0.40, -0.74);
    glVertex2f(-0.23, -0.74);
    glColor3ub(255, 69, 0);
    glVertex2f(-0.23, -0.68);
    glVertex2f(-0.40, -0.68);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 69, 0);
    glVertex2f(-0.40, -0.68);
    glVertex2f(-0.23, -0.68);
    glColor3ub(139, 0, 0);
    glVertex2f(-0.23, -0.62);
    glVertex2f(-0.40, -0.62);
    glEnd();
    glPopMatrix();


    // Character (inside an invisible quad)
  glPushMatrix();
  glTranslatef(characterX, characterY, 0.0f);

  glBegin(GL_QUADS); // Add this line
  glColor3ub(0, 0, 0); // Add this line to make the character black

  // "leg"
  glVertex2f(-0.01, 0.0);
  glVertex2f(0.0075, 0.0);
  glVertex2f(0.0075, -0.03);
  glVertex2f(-0.01, -0.03);
  glVertex2f(0.0125, 0.0);
  glVertex2f(0.0125, -0.03);
  glVertex2f(0.02, -0.03);
  glVertex2f(0.02, 0.0);

  // "body"
  glVertex2f(-0.01, 0.0);
  glVertex2f(0.02, 0.0);
  glVertex2f(0.02, 0.03);
  glVertex2f(-0.01, 0.03);

  // "hand"
  glVertex2f(-0.02, 0.0);
  glVertex2f(-0.02, 0.03);
  glVertex2f(-0.013, 0.03);
  glVertex2f(-0.013, 0.0);
  glVertex2f(0.023, 0.0);
  glVertex2f(0.03, 0.0);
  glVertex2f(0.03, 0.03);
  glVertex2f(0.023, 0.03);

  // "head"
  glVertex2f(-0.01, 0.04);
  glVertex2f(0.02, 0.04);
  glVertex2f(0.02, 0.07);
  glVertex2f(-0.01, 0.07);
  glEnd();

  glPopMatrix();

    glPushMatrix();
    glTranslatef(pivotX, pivotY, 0.0f);
    glRotatef(angle, 0.0f, 0.0f, 1.0f);
    glTranslatef(-pivotX, -pivotY, 0.0f);

    // Draw Spikes
    glBegin(GL_TRIANGLE_FAN);
    glColor3ub(254, 0, 0);
    glVertex2f(-0.87f, 0.24f);
    glVertex2f(-0.86f, 0.27f);
    glVertex2f(-0.84f, 0.27f);
    glVertex2f(-0.87f, 0.24f);
    glVertex2f(-0.84f, 0.23f);
    glVertex2f(-0.84f, 0.21f);
    glVertex2f(-0.87f, 0.24f);
    glVertex2f(-0.88f, 0.21f);
    glVertex2f(-0.90f, 0.21f);
    glVertex2f(-0.87f, 0.24f);
    glVertex2f(-0.90f, 0.25f);
    glVertex2f(-0.90f, 0.27f);
    glEnd();

    glPopMatrix();

    glPushMatrix();
    glTranslatef(pivotX1, pivotY1, 0.0f);
    glRotatef(angle1, 0.0f, 0.0f, 1.0f);
    glTranslatef(-pivotX1, -pivotY1, 0.0f);

    // Draw Spike2
    glBegin(GL_TRIANGLE_FAN);
    glColor3ub(254, 0, 0);
    glVertex2f(-0.40f, 0.53f);
    glVertex2f(-0.39f, 0.56f);
    glVertex2f(-0.37f, 0.56f);
    glVertex2f(-0.40f, 0.53f);
    glVertex2f(-0.37f, 0.52f);
    glVertex2f(-0.37f, 0.50f);
    glVertex2f(-0.40f, 0.53f);
    glVertex2f(-0.41f, 0.50f);
    glVertex2f(-0.43f, 0.50f);
    glVertex2f(-0.40f, 0.53f);
    glVertex2f(-0.43f, 0.54f);
    glVertex2f(-0.43f, 0.56f);
    glEnd();
    glPopMatrix();

    // Laser beams
    glPushMatrix();
    glTranslatef(position1, 0.0f, 0.0f);
    glPointSize(6.0f);
    glBegin(GL_POINTS);
    glColor3ub(255, 0, 0);
    glVertex2f(-0.765, 0.47);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(position2, 0.0f, 0.0f);
    glPointSize(6.0f);
    glBegin(GL_POINTS);
    glColor3ub(255, 0, 0);
    glVertex2f(-0.72, -0.06);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(position3, 0.0f, 0.0f);
    glPointSize(6.0f);
    glBegin(GL_POINTS);
    glColor3ub(255, 0, 0);
    glVertex2f(-0.18, 0.27);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0.0f, position4, 0.0f);
    glPointSize(6.0f);
    glBegin(GL_POINTS);
    glColor3ub(255, 0, 0);
    glVertex2f(0.40, -0.41);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0.0f, position5, 0.0f);
    glPointSize(6.0f);
    glBegin(GL_POINTS);
    glColor3ub(255, 0, 0);
    glVertex2f(-0.31, 0.145);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(position6, 0.0f, 0.0f);
    glPointSize(6.0f);
    glBegin(GL_POINTS);
    glColor3ub(255, 0, 0);
    glVertex2f(0.97, -0.12);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0.0f, position7, 0.0f);
    glPointSize(6.0f);
    glBegin(GL_POINTS);
    glColor3ub(255, 0, 0);
    glVertex2f(0.52, 0.855);
    glEnd();
    glPopMatrix();

    //Maze
    glPushMatrix();
  glBegin(GL_QUADS);
  glColor3ub(64, 39, 34);
  glVertex2f(-1, -1);
  glVertex2f(-0.97, -1);
  glVertex2f(-0.97, 1);
  glVertex2f(-1, 1);
  glVertex2f(-1, -1);
  glVertex2f(-1, -0.94);
  glVertex2f(1, -0.94);
  glVertex2f(1, -1);
  glVertex2f(1, -1);
  glVertex2f(0.97, -1);
  glVertex2f(0.97, 1);
  glVertex2f(1, 1);
  glVertex2f(-1, 1);
  glVertex2f(-1, 0.88);
  glVertex2f(1, 0.88);
  glVertex2f(1, 1);
  glVertex2f(-0.73, 0.24);
  glVertex2f(-0.73, 1);
  glVertex2f(-0.63, 1);
  glVertex2f(-0.63, 0.24);
  glVertex2f(-0.63, 0.18);
  glVertex2f(-0.63, 0.35);
  glVertex2f(-0.20, 0.35);
  glVertex2f(-0.20, 0.18);
  glVertex2f(-1, 0.41);
  glVertex2f(-1, 0.53);
  glVertex2f(-0.87, 0.53);
  glVertex2f(-0.87, 0.41);
  glVertex2f(-1, -0.0);
  glVertex2f(-1, -0.12);
  glVertex2f(-0.77, -0.12);
  glVertex2f(-0.77, -0.0);
  glVertex2f(-0.63, 0.18);
  glVertex2f(-0.50, 0.18);
  glVertex2f(-0.50, -0.24);
  glVertex2f(-0.63, -0.18);
  glVertex2f(-0.63, -0.18);
  glVertex2f(-0.63, -0.29);
  glVertex2f(-0.44, -0.29);
  glVertex2f(-0.44, -0.18);
  glVertex2f(-1, -1);
  glVertex2f(-0.40, -1);
  glVertex2f(-0.40, -0.59);
  glVertex2f(-01, -0.59);
  glVertex2f(-0.23, -1);
  glVertex2f(-0.23, -0.59);
  glVertex2f(1, -0.59);
  glVertex2f(1, -1);
  glVertex2f(-0.23, -0.59);
  glVertex2f(-0.10, -0.59);
  glVertex2f(-0.10, -0.35);
  glVertex2f(-0.23, -0.35);
  glVertex2f(1, -0.59);
  glVertex2f(1, -0.35);
  glVertex2f(0.83, -0.35);
  glVertex2f(0.83, -0.59);
  glVertex2f(1, 0.12);
  glVertex2f(1, 0.24);
  glVertex2f(0.83, 0.24);
  glVertex2f(0.83, 0.12);
  glVertex2f(-0.00, -0.24);
  glVertex2f(0.63, -0.24);
  glVertex2f(0.63, 0.18);
  glVertex2f(-0.0, 0.18);
  glVertex2f(-0.0, 0.18);
  glVertex2f(-0.0, 0.0);
  glVertex2f(-0.23, 0.0);
  glVertex2f(-0.23, 0.18);
  glVertex2f(0.40, 0.18);
  glVertex2f(0.63, 0.18);
  glVertex2f(0.63, 0.47);
  glVertex2f(0.40, 0.47);
  glVertex2f(-0.03, 0.53);
  glVertex2f(-0.03, 0.88);
  glVertex2f(0.23, 0.88);
  glVertex2f(0.23, 0.53);
  glVertex2f(0.63, -0.18);
  glVertex2f(0.77, -0.18);
  glVertex2f(0.77, -0.06);
  glVertex2f(0.63, -0.06);
  glEnd();
  glPopMatrix();


  glFlush();
}

bool isWall(float x, float y) {
    unsigned char pixel[3];
    glReadPixels(
        (x + 1.0f) * glutGet(GLUT_WINDOW_WIDTH) / 2,
        (y + 1.0f) * glutGet(GLUT_WINDOW_HEIGHT) / 2,
        1, 1, GL_RGB, GL_UNSIGNED_BYTE, pixel
    );

    bool isWallColor = (pixel[0] == 64 && pixel[1] == 39 && pixel[2] == 34);
    bool isBackground = (pixel[0] == 217 && pixel[1] == 217 && pixel[2] == 217);
    return isWallColor;
}

bool canMove(float newX, float newY) {
    if (newX < -0.95f || newX > 0.95f || newY < -0.92f || newY > 0.86f) {
        return false;
    }

    float checkPoints[][2] = {
        {newX - CHAR_WIDTH/2, newY},              // Left
        {newX + CHAR_WIDTH/2, newY},              // Right
        {newX, newY + CHAR_HEIGHT/2},             // Top
        {newX, newY - CHAR_HEIGHT/2},             // Bottom
        {newX - CHAR_WIDTH/2, newY + CHAR_HEIGHT/2}, // Top-left
        {newX + CHAR_WIDTH/2, newY + CHAR_HEIGHT/2}, // Top-right
        {newX - CHAR_WIDTH/2, newY - CHAR_HEIGHT/2}, // Bottom-left
        {newX + CHAR_WIDTH/2, newY - CHAR_HEIGHT/2}  // Bottom-right
    };
    for (int i = 0; i < 8; i++) {
        if (isWall(checkPoints[i][0], checkPoints[i][1])) {
            return false;
        }
    }

    return true;
}

void handleJump() {
    if (!isJumping && canMove(characterX, characterY - GROUND_CHECK_DISTANCE)) {
        isJumping = true;
        jumpVelocity = MIN_JUMP_VELOCITY;
    }

    if (isJumping) {
        float newY = characterY + jumpVelocity;
        float heightDifference = newY - jumpStartY;

        if (heightDifference > MAX_JUMP_HEIGHT && jumpVelocity > 0) {
            jumpVelocity = 0;
        }
        jumpVelocity = std::max(jumpVelocity - GRAVITY, MIN_JUMP_VELOCITY);

        if (canMove(characterX, newY)) {
            characterY = newY;
        } else {
            if (jumpVelocity > 0) {
                // Hit ceiling
                jumpVelocity = 0;
            } else {
                // Hit ground
                isJumping = false;
                jumpVelocity = 0;
            }
        }
    }
}
bool isCollisionWithThorn(float x, float y) {
    if ((x >= -0.73f && x <= -0.66f) && (y >= -0.59f && y <= -0.48f)) {
        return true;
    }
    if ((x >= 0.08f && x <= 0.15f) && (y >= -0.59f && y <= -0.50f)) {

        return true;
    }
    if ((x >= 0.65f && x <= 0.72f) && (y >= -0.59f && y <= -0.50f)) {
        return true;
    }
    if ((x >= 0.22f && x <= 0.55f) && (y >= -0.32f && y <= -0.24f)) {
        return true;
    }

    return false;
}

bool isCollisionWithSpike(float x, float y) {
    const float spikeWidth = 0.1f;
    const float spikeHeight = 0.1f;

    return x > (pivotX - spikeWidth / 2) && x < (pivotX + spikeWidth / 2) &&
           y > (pivotY - spikeHeight / 2) && y < (pivotY + spikeHeight / 2);
}
bool isCollisionWithSpike2(float x, float y) {
    const float spikeWidth = 0.1f;
    const float spikeHeight = 0.1f;

    return x > (pivotX1 - spikeWidth / 2) && x < (pivotX1 + spikeWidth / 2) &&
           y > (pivotY1 - spikeHeight / 2) && y < (pivotY1 + spikeHeight / 2);
}

bool isCollisionWithLaser(float x, float y) {
    const float LASER_SIZE = 0.02f;

    // Laser 1
    if (abs(x - (-0.765f + position1)) < LASER_SIZE && abs(y - 0.47f) < LASER_SIZE) return true;
    // Laser 2
    if (abs(x - (-0.72f + position2)) < LASER_SIZE && abs(y - (-0.06f)) < LASER_SIZE) return true;
    // Laser 3
    if (abs(x - (-0.18f + position3)) < LASER_SIZE && abs(y - 0.27f) < LASER_SIZE) return true;
    // Laser 4
    if (abs(x - 0.40f) < LASER_SIZE && abs(y - (-0.41f + position4)) < LASER_SIZE) return true;
    // Laser 5
    if (abs(x - (-0.31f)) < LASER_SIZE && abs(y - (0.145f + position5)) < LASER_SIZE) return true;
    // Laser 6
    if (abs(x - (0.97f + position6)) < LASER_SIZE && abs(y - (-0.12f)) < LASER_SIZE) return true;
    // Laser 7
    if (abs(x - 0.52f) < LASER_SIZE && abs(y - (0.855f + position7)) < LASER_SIZE) return true;

    return false;
}
void resetCharacter() {
    characterX = INITIAL_X;
    characterY = INITIAL_Y;
    isJumping = false;
    jumpVelocity = 0.0f;
    playSound("move.wav");
}

void handleKeypress(unsigned char key, int x, int y) {
    float newX = characterX;
    float newY = characterY;
    if (isNextLevelLaunched) {
        return;
    }

    switch (key) {
        case 'w': // Jump
            if (!isJumping && !canMove(characterX, characterY - GROUND_CHECK_DISTANCE)) {
                isJumping = true;
                jumpVelocity = JUMP_INITIAL_VELOCITY;
                jumpStartY = characterY;
                jumpStartX = characterX;
                playSound("move.wav");
            }
            break;

        case 'a': // Move left
            newX -= moveStep;
            if (canMove(newX, characterY)) {
                characterX = newX;
                playSound("move.wav");
            }
            break;

        case 'd': // Move right
            newX += moveStep;
            if (canMove(newX, characterY)) {
                characterX = newX;
                playSound("move.wav");
            }
            break;

        case 'r': // Reset key
            resetCharacter();
            break;
    }

    if (isCollisionWithSpike(characterX, characterY) ||
        isCollisionWithSpike2(characterX, characterY) ||
        isCollisionWithLaser(characterX, characterY) ||
        isCollisionWithThorn(characterX, characterY)) {
        isNextLevelLaunched = true; // Set the flag
            system("start D:\\Desktop\\MazeRunner\\gameover\\bin\\Debug\\gameover.exe");
            exit(0);
    }

    glutPostRedisplay();
}
void update() {
    handleJump();
    if (isNextLevelLaunched) {
        return;
    }
    if (!isJumping && canMove(characterX, characterY - GROUND_CHECK_DISTANCE)) {
        characterY -= FALL_SPEED;
    }
    if (isCollisionWithSpike(characterX, characterY) ||
        isCollisionWithSpike2(characterX, characterY) ||
        isCollisionWithLaser(characterX, characterY) ||
        isCollisionWithThorn(characterX, characterY)) {
        isNextLevelLaunched = true;
            system("start D:\\Desktop\\MazeRunner\\gameover\\bin\\Debug\\gameover.exe");
            exit(0);
    }

    characterX = std::max(-0.95f, std::min(characterX, 0.95f));
    characterY = std::max(-0.92f, std::min(characterY, 0.86f));
}
void timer(int value) {
    angle += 1.0f;
    if (angle > 360.0f) angle -= 360.0f;
    angle1 += 1.0f;
    if (angle1 > 360.0f) angle1 -= 360.0f;
    update();
    if (isCollisionWithSpike(characterX, characterY) ||
        isCollisionWithSpike2(characterX, characterY) ||
        isCollisionWithLaser(characterX, characterY) ||
        isCollisionWithThorn(characterX, characterY)) {
        resetCharacter();
    }

    glutPostRedisplay();
    glutTimerFunc(16, timer, 0);
}



void init() {
    // Set up the viewport and orthographic projection
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-1.0, 1.0, -1.0, 1.0);
    glMatrixMode(GL_MODELVIEW);
}

int main(int argc, char ** argv) {
    glutInit( & argc, argv);
    glutInitWindowSize(1000, 750);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutCreateWindow("LVL 3 Trans");
    glutDisplayFunc(display);
    glutKeyboardFunc(handleKeypress);
    init();
    glutDisplayFunc(display);
    glutFullScreen();
    glutTimerFunc(0, timer, 0);
    glutTimerFunc(100, updateb1, 0);
    glutTimerFunc(100, updateb2, 0);
    glutTimerFunc(100, updateb3, 0);
    glutTimerFunc(100, updateb4, 0);
    glutTimerFunc(100, updateb5, 0);
    glutTimerFunc(100, updateb6, 0);
    glutTimerFunc(100, updateb7, 0);
  glutMainLoop();
  update();
  return 0;
}
