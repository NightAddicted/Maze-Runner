#include <windows.h>
#include<cstdio>
#include<GL/gl.h>
#include <GL/glut.h>
#include<math.h>
#define PI 3.14159265358979323846

GLfloat position1 = 0.0f;
GLfloat speed1 = 0.01f;
GLfloat position2 = 0.0f;
GLfloat speed2 = 0.01f;
GLfloat position3 = 0.0f;
GLfloat speed3 = 0.03f;
GLfloat position4 = 0.0f;
GLfloat speed4 = 0.03f;
GLfloat position5 = 0.0f;
GLfloat speed5 = 0.03f;
GLfloat position6 = 0.0f;
GLfloat speed6= 0.03f;
GLfloat charX = -0.03f;
GLfloat charY =0.00f;
GLfloat jumpVelocity = 0.00f;
GLfloat gravity = -0.006f;
bool isJumping = false;
const float CHAR_WIDTH = 0.036f;
const float CHAR_HEIGHT = 0.10f;
const float BUFFER = 0.002f;
bool isNextLevelLaunched = false;

void playSound(const char* filename) {
    PlaySound(NULL, NULL, 0); // Stop any currently playing sound
    PlaySound(TEXT(filename), NULL, SND_ASYNC | SND_FILENAME);
}

bool isInsideMazeWall(float x, float y) {
    // Calculate character bounds
    float charLeft = x - (CHAR_WIDTH / 2) - BUFFER;
    float charRight = x + (CHAR_WIDTH / 2) + BUFFER;
    float charTop = y + (CHAR_HEIGHT / 2) + BUFFER;
    float charBottom = y - (CHAR_HEIGHT / 2) - BUFFER;
    auto checkOverlap = [](float wall_x1, float wall_y1, float wall_x2, float wall_y2,
                           float char_x1, float char_y1, float char_x2, float char_y2) {
        return !(char_x2 < wall_x1 || char_x1 > wall_x2 || char_y2 < wall_y1 || char_y1 > wall_y2);
    };

    if (checkOverlap(-1.0f, -1.0f, -0.90f, 1.0f, charLeft, charBottom, charRight, charTop)) return true;
    if (checkOverlap(0.93f, -1.0f, 1.0f, 1.0f, charLeft, charBottom, charRight, charTop)) return true;
    if (checkOverlap(-1.0f, 0.82f, 1.0f, 0.82f, charLeft, charBottom, charRight, charTop)) return true;
    if (checkOverlap(-1.0f, -1.0f, 1.0f, -01.0f, charLeft, charBottom, charRight, charTop)) return true;

    if (checkOverlap(-0.90f, 0.16f, -0.47f, 0.34f, charLeft, charBottom, charRight, charTop)) return true;
    if (checkOverlap(-0.90f, -0.54f, -0.47f, -0.37f, charLeft, charBottom, charRight, charTop)) return true;
    if (checkOverlap(-0.66f, -0.19f, -0.27f, -0.01f, charLeft, charBottom, charRight, charTop)) return true;
    if (checkOverlap(-0.66f, -0.83f, -0.27f, -0.72f, charLeft, charBottom, charRight, charTop)) return true;

    if (checkOverlap(-0.27f, -0.83f, -0.16f, 0.46f, charLeft, charBottom, charRight, charTop)) return true;
    if (checkOverlap(-0.16f, -0.60f, 0.76f, -0.42f, charLeft, charBottom, charRight, charTop)) return true;

    if (checkOverlap(0.76f, -1.0f, 0.96f, -0.24f, charLeft, charBottom, charRight, charTop)) return true;
    if (checkOverlap(0.53f, -1.0f, 0.76f, -0.60f, charLeft, charBottom, charRight, charTop)) return true;

    if (checkOverlap(-0.17f, 0.34f, 0.63f, 0.46f, charLeft, charBottom, charRight, charTop)) return true;
    if (checkOverlap(0.10f, -0.07f, 0.40f, 0.34f, charLeft, charBottom, charRight, charTop)) return true;

    if (checkOverlap(-0.07f, -0.25f, 0.63f, -0.07f, charLeft, charBottom, charRight, charTop)) return true;
    if (checkOverlap(0.79f, -0.01f, 0.96f, 0.16f, charLeft, charBottom, charRight, charTop)) return true;

    return false;
}
void handleSpikeCollision() {
    if (isNextLevelLaunched) {
        return;
    }
    float spikes[4][4] = {
    {0.59f, 0.67f, 0.07f, -0.13f},
    //{0.36f, 0.44f, 0.67f - 0.05f, 0.57f - 0.05f},
    //{-0.01f, 0.07f, 0.67f - 0.05f, 0.57f - 0.05f},
    {-0.82f, -0.74f, 0.58f - 0.05f, 0.48f - 0.05f},
    {-0.82f, -0.74f, 0.08f - 0.05f, -0.02f - 0.05f},
    {-0.05df, 0.01f, -0.78f - 0.05f, -0.89f - 0.05f}
};

    float charLeft = charX - (CHAR_WIDTH / 2) - BUFFER;
    float charRight = charX + (CHAR_WIDTH / 2) + BUFFER;
    float charTop = charY + (CHAR_HEIGHT / 0.5) + BUFFER;
    float charBottom = charY - (CHAR_HEIGHT / 1.2) - BUFFER;


    for (int i = 0; i < 4; i++) {
        float spikeLeft = spikes[i][0];
        float spikeRight = spikes[i][1];
        float spikeTop = spikes[i][2];
        float spikeBottom = spikes[i][3];

        if (!(charRight < spikeLeft || charLeft > spikeRight || charTop < spikeBottom || charBottom > spikeTop)) {
            isNextLevelLaunched = true;
            system("start D:\\Desktop\\MazeRunner\\gameover\\bin\\Debug\\gameover.exe");
            exit(0);
        }
    }
}

void nextlevel() {
    if (isNextLevelLaunched) {
        return;
    }

    float spikes[1][4] = {
        {0.40f, 0.47f, -0.76f , -0.88f},
    };

    float charLeft = charX - (CHAR_WIDTH / 2) - BUFFER;
    float charRight = charX + (CHAR_WIDTH / 2) + BUFFER;
    float charTop = charY + (CHAR_HEIGHT / 0.5) + BUFFER;
    float charBottom = charY - (CHAR_HEIGHT / 1.2) - BUFFER;

    for (int i = 0; i < 1; i++) {
        float spikeLeft = spikes[i][0];
        float spikeRight = spikes[i][1];
        float spikeTop = spikes[i][2];
        float spikeBottom = spikes[i][3];

        if (!(charRight < spikeLeft || charLeft > spikeRight || charTop < spikeBottom || charBottom > spikeTop)) {
            isNextLevelLaunched = true;
            system("start D:\\Desktop\\MazeRunner\\Lvl3\\bin\\Debug\\Lvl3.exe");
            exit(0);
        }
    }
}

void updateJump(int value) {
    if (isJumping) {
        float newY = charY + jumpVelocity;
        jumpVelocity += gravity;
        if (!isInsideMazeWall(charX, newY)) {
            charY = newY;
        } else {
            isJumping = false;
            jumpVelocity = 0.0f;
        }

        if (charY - 0.03f <= -0.98f) {
            charY = -0.98f + 0.03f;
            isJumping = false;
            jumpVelocity = 0.0f;
        }
    } else {
        float newY = charY + jumpVelocity;
        jumpVelocity += gravity;

        if (!isInsideMazeWall(charX, newY)) {
            charY = newY;
        } else {
            jumpVelocity = 0.0f;
        }

        if (charY - 0.03f <= -0.98f) {
            charY = -0.98f + 0.03f;
            jumpVelocity = 0.0f;
        }
    }

    handleSpikeCollision();

    glutPostRedisplay();
    glutTimerFunc(50, updateJump, 0);
}
void keyboard(unsigned char key, int x, int y) {
    float step = 0.03f;
    float newX = charX;

    if (key == 'a') {
        newX -= step;
        playSound("move.wav");
    }
    if (key == 'd') {
        newX += step;
        playSound("move.wav");
    }
    if (!isInsideMazeWall(newX, charY)) {
        charX = newX;
    }

    if (key == 'w' && !isJumping) {
        isJumping = true;
        jumpVelocity = 0.08f;
        playSound("jump.wav");
    }

    handleSpikeCollision();
    nextlevel();
    glutPostRedisplay();
}


void updateb1(int value) {
        if (isNextLevelLaunched) {
        return;
    }

    position1 += speed1;
    if (position1 > 0.93f) {
        position1 = -0.0f;
    }

    GLfloat nposx = -0.20f + position1;
    GLfloat posy = -0.21f;

    GLfloat charLeft = charX - (CHAR_WIDTH / 2) - BUFFER;
    GLfloat charRight = charX + (CHAR_WIDTH / 2) + BUFFER;
    GLfloat charTop = charY + (CHAR_HEIGHT * 2) - BUFFER;
    GLfloat charBottom = charY - (CHAR_HEIGHT / 1.2) + BUFFER;

    if (nposx > charLeft && nposx < charRight && posy > charBottom && posy < charTop) {
        isNextLevelLaunched = true; // Set the flag
            system("start D:\\Desktop\\MazeRunner\\gameover\\bin\\Debug\\gameover.exe");
            exit(0);
    }

    glutPostRedisplay();
    glutTimerFunc(30, updateb1, 0);
}
void updateb2(int value2) {
        if (isNextLevelLaunched) {
        return;
    }

    position2 += speed2;
    if (position2 > 0.24f) {
        position2 = -0.0f;
    }

    GLfloat nposx = -0.50f + position2;
    GLfloat posy = 0.37f;

    GLfloat charLeft = charX - (CHAR_WIDTH / 2) - BUFFER;
    GLfloat charRight = charX + (CHAR_WIDTH / 2) + BUFFER;
    GLfloat charTop = charY + (CHAR_HEIGHT / 0.5) - BUFFER;
    GLfloat charBottom = charY - (CHAR_HEIGHT / 1.2) + BUFFER;

    if (nposx > charLeft && nposx < charRight && posy > charBottom && posy < charTop) {
        isNextLevelLaunched = true; // Set the flag
            system("start D:\\Desktop\\MazeRunner\\gameover\\bin\\Debug\\gameover.exe");
            exit(0);
    }

    glutPostRedisplay();
    glutTimerFunc(150, updateb2, 0);
}
void updateb3(int value3) {
        if (isNextLevelLaunched) {
        return;
    }

    position3 += speed3;
    if (position3 > 0.60f) {
        position3 = -0.93f;
    }

    GLfloat nposx = -0.93f + position3;
    GLfloat posy = -0.15f;

    GLfloat charLeft = charX - (CHAR_WIDTH / 2) - BUFFER;
    GLfloat charRight = charX + (CHAR_WIDTH / 2) + BUFFER;
    GLfloat charTop = charY + (CHAR_HEIGHT / 0.5) - BUFFER;
    GLfloat charBottom = charY - (CHAR_HEIGHT / 2) + BUFFER;

    if (nposx > charLeft && nposx < charRight && posy > charBottom && posy < charTop) {
        isNextLevelLaunched = true;
            system("start D:\\Desktop\\MazeRunner\\gameover\\bin\\Debug\\gameover.exe");
            exit(0);
    }

    glutPostRedisplay();
    glutTimerFunc(100, updateb3, 0);
}
void updateb4(int value4) {
        if (isNextLevelLaunched) {
        return;
    }

    position4 += speed4;
    if (position4 > 0.20f) {
        position4 = -0.93f;
    }

    GLfloat nposx = -0.93f + position4;
    GLfloat posy = -0.63f;

    GLfloat charLeft = charX - (CHAR_WIDTH / 2) - BUFFER;
    GLfloat charRight = charX + (CHAR_WIDTH / 2) + BUFFER;
    GLfloat charTop = charY + (CHAR_HEIGHT / 0.5) - BUFFER;
    GLfloat charBottom = charY - (CHAR_HEIGHT / 1.2) + BUFFER;

    if (nposx > charLeft && nposx < charRight && posy > charBottom && posy < charTop) {
        isNextLevelLaunched = true;
            system("start D:\\Desktop\\MazeRunner\\gameover\\bin\\Debug\\gameover.exe");
            exit(0);
    }

    glutPostRedisplay();
    glutTimerFunc(100, updateb4, 0);
}
void updateb5(int value5) {
        if (isNextLevelLaunched) {
        return;
    }

    position5 -= speed5;
    if (position5 < -0.90f) {
        position5 = 0.10;
    }

    GLfloat nposx = 0.12f;
    GLfloat posy = -0.47f + position5;

    GLfloat charLeft = charX - (CHAR_WIDTH / 2) - BUFFER;
    GLfloat charRight = charX + (CHAR_WIDTH / 2) + BUFFER;
    GLfloat charTop = charY + (CHAR_HEIGHT / 0.5) - BUFFER;
    GLfloat charBottom = charY - (CHAR_HEIGHT / 1.2) + BUFFER;

    if (nposx > charLeft && nposx < charRight && posy > charBottom && posy < charTop) {
        isNextLevelLaunched = true; // Set the flag
            system("start D:\\Desktop\\MazeRunner\\gameover\\bin\\Debug\\gameover.exe");
            exit(0);
    }

    glutPostRedisplay();
    glutTimerFunc(100, updateb5, 0);
}
void updateb6(int value6) {
        if (isNextLevelLaunched) {
        return;
    }

    position6 -= speed6;
    if (position6 < -0.60f) {
        position6 = 0.0;
    }

    GLfloat nposx = 0.79f;
    GLfloat posy = 0.92f + position6;

    GLfloat charLeft = charX - (CHAR_WIDTH / 2) - BUFFER;
    GLfloat charRight = charX + (CHAR_WIDTH / 2) + BUFFER;
    GLfloat charTop = charY + (CHAR_HEIGHT * 2) - BUFFER;
    GLfloat charBottom = charY - (CHAR_HEIGHT / 1.2) + BUFFER;

    if (nposx > charLeft && nposx < charRight && posy > charBottom && posy < charTop) {
        isNextLevelLaunched = true;
            system("start D:\\Desktop\\MazeRunner\\gameover\\bin\\Debug\\gameover.exe");
            exit(0);
    }

    glutPostRedisplay();
    glutTimerFunc(120, updateb6, 0);
}

void display()
{
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
	glClear(GL_COLOR_BUFFER_BIT);

	//Background
	glBegin(GL_POLYGON);
	glColor3ub(124,183,168);
	glVertex2f(-1,1);
	glVertex2f(-1,-1);
	glVertex2f(1,-1);
	glVertex2f(1,1);
	glEnd();

	//circle
    int i;

	GLfloat x=0.57f; GLfloat y=0.29f; GLfloat radius =.35f;
	int triangleAmount = 100;

	GLfloat twicePi = 2.0f * PI;
	glColor3ub(136,196,167);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y);
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(162,205,179);
	glVertex2f(-0.20,-0.24);
	glVertex2f(1,-0.24);
	glVertex2f(1,-1);
	glVertex2f(-0.20,-1);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(136,196,167);
	glVertex2f(-0.50,-0.70);
	glVertex2f(-1,-0.70);
	glVertex2f(-0.70,-0.35);
	glVertex2f(-0.20,-0.35);
	glVertex2f(0.20,-0.75);
	glVertex2f(0.40,-0.75);
	glVertex2f(0.40,-1);
	glVertex2f(-1,-1);
	glVertex2f(-1,-0.70);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(136,196,167);
	glVertex2f(0.40,-0.75);
	glVertex2f(0.40,-1);
	glVertex2f(1,0.12);
	glVertex2f(1,-1);
	glVertex2f(0.40,-1);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(113,174,161);
	glVertex2f(-0.87,0.76);
	glVertex2f(-0.63,0.82);
	glVertex2f(-0.67,0.76);
	glVertex2f(-0.70,0.72);
	glVertex2f(-0.77,0.70);
	glVertex2f(-0.77,0.70);
	glVertex2f(-0.83,0.53);
	glVertex2f(-0.80,0.47);
	glVertex2f(-1,0.41);
	glVertex2f(-1,0.82);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(113,174,161);
	glVertex2f(-0.93,0.0);
	glVertex2f(-0.93,0.41);
	glVertex2f(-0.82,0.18);
	glVertex2f(-0.88,0.04);
	glVertex2f(-0.81,0);
	glVertex2f(-0.81,-0.18);
	glVertex2f(-0.77,-0.24);
	glVertex2f(-0.93,-0.24);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(113,174,161);
	glVertex2f(-0.83,-0.57);
	glVertex2f(-0.93,-0.41);
	glVertex2f(-0.87,-0.41);
	glVertex2f(-0.73,-0.55);
	glVertex2f(-0.70,-0.70);
	glVertex2f(-0.63,-0.88);
	glVertex2f(-0.75,-0.88);
	glVertex2f(-0.80,-0.76);
	glVertex2f(-0.83,-0.57);
	glVertex2f(-0.87,-0.70);
	glVertex2f(-0.78,-0.82);
	glVertex2f(-0.80,-0.88);
	glVertex2f(-0.93,-0.88);
	glVertex2f(-0.93,-0.41);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(162,205,179);
	glVertex2f(-0.87,0.65);
	glVertex2f(-0.87,0.70);
	glVertex2f(-0.77,0.67);
	glVertex2f(-0.70,0.67);
	glVertex2f(-0.63,0.59);
	glVertex2f(-0.53,0.59);
	glVertex2f(-0.70,0.59);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(162,205,179);
	glVertex2f(0.87,0.65);
	glVertex2f(0.87,0.70);
	glVertex2f(0.77,0.67);
	glVertex2f(0.70,0.67);
	glVertex2f(0.63,0.59);
	glVertex2f(0.53,0.59);
	glVertex2f(0.70,0.59);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(162,205,179);
	glVertex2f(-0.87,-0.65);
	glVertex2f(-0.87,-0.70);
	glVertex2f(-0.77,-0.67);
	glVertex2f(-0.70,-0.67);
	glVertex2f(-0.63,-0.59);
	glVertex2f(-0.53,-0.59);
	glVertex2f(-0.70,-0.59);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(162,205,179);
	glVertex2f(0.20,0.65);
	glVertex2f(0.20,0.70);
	glVertex2f(0.50,0.67);
	glVertex2f(0.50,0.67);
	glVertex2f(0.43,0.59);
	glVertex2f(0.33,0.59);
	glVertex2f(0.20,0.59);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(162,205,179);
	glVertex2f(-0.20,0.65);
	glVertex2f(-0.20,0.70);
	glVertex2f(-0.50,0.67);
	glVertex2f(-0.50,0.67);
	glVertex2f(-0.43,0.59);
	glVertex2f(-0.33,0.59);
	glVertex2f(-0.20,0.59);
	glVertex2f(-0.20,-0.59);
	glVertex2f(-0.33,-0.59);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(162,205,179);
	glVertex2f(-0.50,-0.25);
	glVertex2f(-0.60,-0.30);
	glVertex2f(-0.650,-0.67);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(162,205,179);
	glVertex2f(-0.50,0);
	glVertex2f(-0.40,0);
	glVertex2f(-0.20,-0.29);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(162,205,179);
	glVertex2f(-0.20,0.12);
	glVertex2f(-0.20,0.18);
	glVertex2f(-0.13,0.18);
	glVertex2f(0.0,0.25);
	glVertex2f(-0.06,0.12);
	glVertex2f(-0.06,0.06);
	glVertex2f(-0.01,0.03);
	glVertex2f(-0.20,0.12);
	glEnd();

	//laserbeam
    glPushMatrix();
    glTranslatef(position1,0.0f, 0.0f);
	glPointSize(6.0f);
	glBegin(GL_POINTS);
	glColor3ub(255, 0, 0);
	glVertex2f(-0.20,-0.21);
	glEnd();
	glPopMatrix();

	glPushMatrix();
    glTranslatef(position2,0.0f, 0.0f);
	glPointSize(6.0f);
	glBegin(GL_POINTS);
	glColor3ub(255, 0, 0);
	glVertex2f(-0.50,0.37);
	glEnd();
	glPopMatrix();

	glPushMatrix();
    glTranslatef(position3,0.0f, 0.0f);
	glPointSize(6.0f);
	glBegin(GL_POINTS);
	glColor3ub(255, 0, 0);
	glVertex2f(-0.93,-0.15);
	glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(position4,0.0f, 0.0f);
	glPointSize(6.0f);
	glBegin(GL_POINTS);
	glColor3ub(255, 0, 0);
	glVertex2f(-0.93,-0.63);
	glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0.0f, position5, 0.0f);
	glPointSize(6.0f);
	glBegin(GL_POINTS);
	glColor3ub(255, 0, 0);
	glVertex2f(0.12,-0.47);
	glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0.0f, position6, 0.0f);
	glPointSize(6.0f);
	glBegin(GL_POINTS);
	glColor3ub(255, 0, 0);
	glVertex2f(0.79,0.82);
	glEnd();
    glPopMatrix();

	//MAZE
	glBegin(GL_QUADS);
	glColor3ub(255,255,255);
	glVertex2f(-1,1);
	glVertex2f(-0.93,1);
	glVertex2f(-0.93,-1);
	glVertex2f(-1,-1);
	glVertex2f(-1,-1);
	glVertex2f(-1,-0.88);
	glVertex2f(1,-0.88);
	glVertex2f(1,-1);
	glVertex2f(1,-1);
	glVertex2f(0.93,-1);
	glVertex2f(0.93,1);
	glVertex2f(1,1);
	glVertex2f(1,1);
	glVertex2f(1,0.93);
	glVertex2f(-1,0.93);
	glVertex2f(-1,1);

	glVertex2f(-0.93,0.45);
	glVertex2f(-0.93,0.29);
	glVertex2f(-0.50,0.29);
	glVertex2f(-0.50,0.45);
	glVertex2f(-0.93,-0.41);
	glVertex2f(-0.93,-0.24);
	glVertex2f(-0.50,-0.24);
	glVertex2f(-0.50,-0.41);

	glVertex2f(-0.67,-0.06);
	glVertex2f(-0.67,0.11);
	glVertex2f(-0.30,0.11);
	glVertex2f(-0.30,-0.06);
	glVertex2f(-0.70,-0.60);
	glVertex2f(-0.70,-0.73);
	glVertex2f(-0.30,-0.73);
	glVertex2f(-0.30,-0.60);

	glVertex2f(-0.30,-0.73);
	glVertex2f(-0.20,-0.73);
	glVertex2f(-0.20,0.58);
	glVertex2f(-0.30,0.58);

	glVertex2f(-0.20,-0.30);
	glVertex2f(-0.20,-0.47);
	glVertex2f(0.73,-0.47);
	glVertex2f(0.73,-0.30);
	glVertex2f(0.73,-0.12);
	glVertex2f(0.93,-0.12);
	glVertex2f(0.93,-1);
	glVertex2f(0.73,-1);
	glVertex2f(0.73,-1);
	glVertex2f(0.50,-1);
	glVertex2f(0.50,-0.47);
	glVertex2f(0.73,-0.47);

	glVertex2f(-0.20,0.58);
	glVertex2f(-0.20,0.45);
	glVertex2f(0.60,0.45);
	glVertex2f(0.60,0.58);
	//here
	glVertex2f(0.07,0.47);
	glVertex2f(0.07,0.04);
	glVertex2f(0.37,0.04);
	glVertex2f(0.37,0.47);

	glVertex2f(-0.10,0.04);
	glVertex2f(-0.10,-0.12);
	glVertex2f(0.60,-0.12);
	glVertex2f(0.60,0.04);

	glVertex2f(0.77,0.12);
	glVertex2f(0.93,0.12);
	glVertex2f(0.93,0.28);
	glVertex2f(0.77,0.28);

	glEnd();

	//mazetrap
	/*glPushMatrix();
    glTranslatef(0.0f, blocktrap, 0.0f);
	glBegin(GL_QUADS);
	glColor3ub(255,255,255);
	glVertex2f(-0.20,-0.70);
	glVertex2f(-0.23,-0.70);
	glVertex2f(-0.23,-0.88);
	glVertex2f(-0.20,-0.88);
	glEnd();
	glPopMatrix();*/

	//Character
	glPushMatrix();
    glTranslatef(charX, charY, 0.0f);
	glBegin(GL_QUADS);
	glColor3ub(0,0,0);
	glVertex2f(-0.03,0.06);//l
	glVertex2f(-0.03,0.09);
	glVertex2f(-0.021,0.09);
	glVertex2f(-0.021,0.06);
	glVertex2f(-0.01,0.06);
	glVertex2f(-0.01,0.09);
	glVertex2f(-0.019,0.09);
	glVertex2f(-0.019,0.06);

	glVertex2f(-0.03,0.09);//b
	glVertex2f(-0.01,0.09);
	glVertex2f(-0.01,0.12);
	glVertex2f(-0.03,0.12);

	glVertex2f(-0.031,0.09);//h
	glVertex2f(-0.031,0.12);
	glVertex2f(-0.038,0.12);
	glVertex2f(-0.038,0.09);
	glVertex2f(-0.002,0.09);
	glVertex2f(-0.009,0.09);
	glVertex2f(-0.009,0.12);
	glVertex2f(-0.002,0.12);


	glVertex2f(-0.03,0.13);
	glVertex2f(-0.01,0.13);
	glVertex2f(-0.01,0.16);
	glVertex2f(-0.03,0.16);

	glEnd();
	glPopMatrix();

	//Trap
	glBegin(GL_POLYGON);//laser1
	glColor3ub(89, 89, 89);
	glVertex2f(-0.20,-0.21);
	glVertex2f(-0.20,-0.14);
	glVertex2f(-0.18,-0.18);
	glVertex2f(-0.18,-0.20);
	glVertex2f(-0.16,-0.20);
	glVertex2f(-0.16,-0.22);
	glVertex2f(-0.18,-0.22);
	glVertex2f(-0.18,-0.24);
	glVertex2f(-0.20,-0.29);
	glEnd();

	glBegin(GL_POLYGON);//laser2
	glColor3ub(89, 89, 89);
	glVertex2f(-0.50,0.37);
	glVertex2f(-0.50,0.30);
	glVertex2f(-0.48,0.34);
	glVertex2f(-0.48,0.36);
	glVertex2f(-0.46,0.36);
	glVertex2f(-0.46,0.38);
	glVertex2f(-0.48,0.38);
	glVertex2f(-0.48,0.40);
	glVertex2f(-0.50,0.45);
	glEnd();

	glBegin(GL_POLYGON);//laser3
	glColor3ub(89, 89, 89);
	glVertex2f(-0.93,-0.15);
	glVertex2f(-0.93,-0.08);
	glVertex2f(-0.91,-0.12);
	glVertex2f(-0.91,-0.14);
	glVertex2f(-0.89,-0.14);
	glVertex2f(-0.89,-0.16);
	glVertex2f(-0.91,-0.16);
	glVertex2f(-0.91,-0.18);
	glVertex2f(-0.93,-0.23);
	glEnd();

	glBegin(GL_POLYGON);//laser4
	glColor3ub(89, 89, 89);
	glVertex2f(-0.93,-0.63);
	glVertex2f(-0.93,-0.56);
	glVertex2f(-0.91,-0.60);
	glVertex2f(-0.91,-0.62);
	glVertex2f(-0.89,-0.62);
	glVertex2f(-0.89,-0.64);
	glVertex2f(-0.91,-0.64);
	glVertex2f(-0.91,-0.66);
	glVertex2f(-0.93,-0.71);
	glEnd();

	glBegin(GL_POLYGON);//laser5
	glColor3ub(89, 89, 89);
	glVertex2f(0.12,-0.47);
	glVertex2f(0.07,-0.47);
	glVertex2f(0.09,-0.49);
	glVertex2f(0.11,-0.49);
	glVertex2f(0.11,-0.51);
	glVertex2f(0.13,-0.51);
	glVertex2f(0.13,-0.49);
	glVertex2f(0.15,-0.49);
	glVertex2f(0.17,-0.47);
	glEnd();

	glBegin(GL_POLYGON);//laser6
	glColor3ub(89, 89, 89);
	glVertex2f(0.79,0.93);
	glVertex2f(0.74,0.93);
	glVertex2f(0.76,0.80);
	glVertex2f(0.78,0.80);
	glVertex2f(0.78,0.78);
	glVertex2f(0.80,0.78);
	glVertex2f(0.80,0.80);
	glVertex2f(0.82,0.80);
	glVertex2f(0.84,0.93);
	glEnd();

	glBegin(GL_POLYGON);//s1
	glColor3ub(89, 89, 89);
	glVertex2f(0.62,-0.02);
	glVertex2f(0.63, 0.01);//initx
	glVertex2f(0.64,-0.02);
	glVertex2f(0.66,-0.03);//inity
	glVertex2f(0.64,-0.04);
	glVertex2f(0.63,-0.07);
	glVertex2f(0.62,-0.04);
	glVertex2f(0.60,-0.03);
	glEnd();

	/*glBegin(GL_POLYGON);//s2
	glColor3ub(89, 89, 89);
	glVertex2f(0.39,0.63);
	glVertex2f(0.40,0.66);//initx
	glVertex2f(0.41,0.63);
	glVertex2f(0.43,0.62);//inity
	glVertex2f(0.41,0.61);
	glVertex2f(0.40,0.58);
	glVertex2f(0.39,0.61);
	glVertex2f(0.37,0.62);
	glEnd();

	glBegin(GL_POLYGON);//s3
	glColor3ub(89, 89, 89);
	glVertex2f(0.02,0.63);//x-1;;;y+1
	glVertex2f(0.03,0.66);//initx;y+4
	glVertex2f(0.04,0.63);//x+1;;;y+1
	glVertex2f(0.06,0.62);//x+3;;;inity
	glVertex2f(0.04,0.61);//x+1;;;y-1
	glVertex2f(0.03,0.58);//initx;y-4
	glVertex2f(0.02,0.61);//x-1;;;y-1
	glVertex2f(0.00,0.62);//x-3;;;inity
	glEnd();*/

	glBegin(GL_POLYGON);//s4
	glColor3ub(89, 89, 89);
	glVertex2f(-0.77,0.54);//x-1;;;y+1
	glVertex2f(-0.78,0.57);//initx;y+4
	glVertex2f(-0.79,0.54);//x+1;;;y+1
	glVertex2f(-0.81,0.53);//x+3;;;inity
	glVertex2f(-0.79,0.52);//x+1;;;y-1
	glVertex2f(-0.78,0.49);//initx;y-4
	glVertex2f(-0.77,0.52);//x-1;;;y-1
	glVertex2f(-0.75,0.53);//x-3;;;inity
	glEnd();

	glBegin(GL_POLYGON);//s5
	glColor3ub(89, 89, 89);
	glVertex2f(-0.77,0.04);//x-1;;;y+1
	glVertex2f(-0.78,0.07);//initx;y+4
	glVertex2f(-0.79,0.04);//x+1;;;y+1
	glVertex2f(-0.81,0.03);//x+3;;;inity
	glVertex2f(-0.79,0.02);//x+1;;;y-1
	glVertex2f(-0.78,-0.01);//initx;y-4
	glVertex2f(-0.77,0.02);//x-1;;;y-1
	glVertex2f(-0.75,0.03);//x-3;;;inity
	glEnd();

	glBegin(GL_POLYGON);//s6
	glColor3ub(89, 89, 89);
	glVertex2f(-0.02,-0.84);//x-1;;;y+1
	glVertex2f(-0.03,-0.88);//initx;y+4
	glVertex2f(-0.04,-0.84);//x+1;;;y+1
	glVertex2f(-0.06,-0.83);//x+3;;;inity
	glVertex2f(-0.04,-0.82);//x+1;;;y-1
	glVertex2f(-0.03,-0.79);//initx;y-4
	glVertex2f(-0.02,-0.82);//x-1;;;y-1
	glVertex2f(-0.00,-0.83);//x-3;;;inity
	glEnd();

	glBegin(GL_LINES);
	glColor3ub(255,0,0);
	glVertex2f(0.40f,-0.88f);
	glVertex2f(0.46f,-0.88f);
	glEnd();

	glFlush();
}
int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitWindowSize(1000, 750);
    glutCreateWindow("Level 2");
    glutFullScreen();
    glutDisplayFunc(display);
    glutTimerFunc(100, updateb1, 0);
    glutTimerFunc(100, updateb2, 0);
    glutTimerFunc(100, updateb3, 0);
    glutTimerFunc(100, updateb4, 0);
    glutTimerFunc(100, updateb5, 0);
    glutTimerFunc(100, updateb6, 0);
    glutTimerFunc(32, updateJump, 0);
    glutKeyboardFunc(keyboard);
    glutMainLoop();
    return 0;
}
